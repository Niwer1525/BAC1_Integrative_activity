package hexmo.views.components;

import java.awt.*;

public interface Drawable {
    void draw(Graphics2D renderer);
}
