package hexmo.supervisors.commons;

/**
 * Liste le nom des différents écrans.
 * */
public enum ViewId {
	MAIN_MENU, PLAY_GAME, NONE, END_GAME
}
