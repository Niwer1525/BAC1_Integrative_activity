package treasurequest.domains;

import static org.junit.Assert.assertEquals;

import java.time.Duration;

import org.junit.jupiter.api.Test;


class PlayerTest {
	
	@Test
	void it_knows_its_coins_and_position() {
		var player = new Player(40, Coordinates.ORIGIN);
		
		assertEquals(40, player.getCoins());
		assertEquals(Coordinates.ORIGIN, player.getPosition());
	}
	
	@Test
	void it_moves_to_another_position() {
		var player = new Player(40, Coordinates.ORIGIN);
		
		player.reset(Coordinates.ofRowAndCol(4, 2));
		
		assertEquals(Coordinates.ofRowAndCol(4, 2), player.getPosition());
	}
	
	@Test
	void it_moves_depending_of_a_direction() {
		var player = new Player(40, Coordinates.ofRowAndCol(4, 2));
		
		player.move(1, 0);
		
		assertEquals(Coordinates.ofRowAndCol(5, 2), player.getPosition());
	}
	
	@Test
	void it_receives_coins() {
		var player = new Player(40, Coordinates.ofRowAndCol(4, 2));
		
		player.receiveCoins(2);
		
		assertEquals(42, player.getCoins());
	}
	
	@Test
	void it_spends_coins() {
		var player = new Player(40, Coordinates.ofRowAndCol(4, 2));
	
		player.spendCoins(2);
		
		assertEquals(38, player.getCoins());
	}
	
	@Test
	void it_keeps_track_of_incomes_and_expenses() {
		var player = new Player(40, Coordinates.ofRowAndCol(4, 2));
		
		player.spendCoins(2);
		player.receiveCoins(10);
		player.spendCoins(5);
		
		assertEquals(43, player.getCoins());
		assertEquals(7, player.getSpentCoins());
		assertEquals(50, player.getReceivedCoins());
	}
		
	@Test
	void it_keeps_track_of_total_game_time() {
		var player = new Player(40, Coordinates.ofRowAndCol(4, 2));
		
	    player.addGameTime(Duration.ofMillis(60500));  
	    player.addGameTime(Duration.ofMillis(12500));
	    
	    assertEquals(Duration.ofMillis(73000), player.getGameTime());
	}
	
	@Test
	void it_returns_its_largest_explored_zone() {
		var caseMap = sample2WithTreasures();
		var player = new Player(40, Coordinates.ORIGIN);
		
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(1, 0);
		player.dig(caseMap);
		
		player.move(0, -1);
		player.dig(caseMap);
		
		var largestZone = player.getLargestZone();
		
		assertEquals(CaseType.FOREST, largestZone.getType());
		assertEquals(4, largestZone.getSize());
	}
	
	@Test
	void it_favors_zone_with_the_biggest_size() {
		var caseMap = sample2WithTreasures();
		var player = new Player(40, Coordinates.ORIGIN);
		
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		
		var largestZone = player.getLargestZone();
		
		assertEquals(CaseType.GRASSLAND, largestZone.getType());
		assertEquals(3, largestZone.getSize());
	}
	
	@Test
	void it_favors_the_oldest_zone_when_size_equality_conflict_arise() {
		var caseMap = sample2WithTreasures();
		var player = new Player(40, Coordinates.ORIGIN);
		
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(0, 1);
		player.dig(caseMap);
		
		player.move(3, 0);
		player.dig(caseMap);
		
		
		player.move(0, 1);
		player.dig(caseMap);
		
		
		player.move(0, 1);
		player.dig(caseMap);
		
		
		var largestZone = player.getLargestZone();
		
		assertEquals(CaseType.GRASSLAND, largestZone.getType());
		assertEquals(3, largestZone.getSize());
	}
	
	@Test
	void it_ignores_digging_when_undiggable_case() {
		var caseMap = sample2WithTreasures();
		var player = new Player(40, Coordinates.ORIGIN);
		
		player.move(4, 0);
		player.dig(caseMap);
		
		assertEquals(40, player.getCoins());
	}

	private CaseMap sample2WithTreasures() {
		var newMap = CaseMapTestData.sample2();
		
		newMap.setAmountAt(12, Coordinates.ofRowAndCol(0, 4));
		newMap.setAmountAt(10, Coordinates.ofRowAndCol(2, 0));
		newMap.setAmountAt(10, Coordinates.ofRowAndCol(2, 2));
		newMap.setAmountAt(20, Coordinates.ofRowAndCol(5, 4));
		newMap.setAmountAt(20, Coordinates.ofRowAndCol(5, 6));
		
		
		return newMap;
	}
}
