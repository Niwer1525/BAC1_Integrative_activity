package treasurequest.domains;

/**
 * Cette classe est utilisée pour tester la fabrique de jeu et s'assurer qu'elle appelle
 * la méthode setClues(CaseMap).
 * */
class FakeCluesSetter implements CluesSetter {

	private int callCount;

	@Override
	public void setClues(CaseMap map) {
		callCount = getCallsCount() + 1;		
	}

	int getCallsCount() {
		return callCount;
	}

}
