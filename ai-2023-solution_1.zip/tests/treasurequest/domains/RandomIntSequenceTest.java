package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RandomIntSequenceTest {

	private final RandomGenerator randomGenerator = new RandomGenerator();

	@Test
	void it_returns_pseudo_random_values_between_min_and_max() {
		int[] values = new int[11];
		
		for (int i = 0; i < 10000; i++) {
			int randomValue = randomGenerator.nextBetween(10, 20);
			++values[randomValue-10];
		}
		
		for(int pos=0; pos < values.length; ++pos) {
			assertEquals(1000, values[pos], 250);
		}
	}
}
