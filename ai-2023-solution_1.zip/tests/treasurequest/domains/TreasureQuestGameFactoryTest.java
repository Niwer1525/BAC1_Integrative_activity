package treasurequest.domains;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

class TreasureQuestGameFactoryTest {
    private static final String ALL_TYPES_MAP = "resources/maps/map-test-3.txt";
    private static final String BIGGER_MAP = "resources/maps/map-test-1.txt";
    
	@Test
	void it_creates_new_games_from_a_map() {
		IntSequence treasureValues = new FakeIntSequence(4, 5);
		var treasureCoords = new FakeCoordinatesSequence(Coordinates.ofRowAndCol(1, 0));
		
		TreasureQuestGameFactory treasureQuestGameFactory = new TreasureQuestGameFactory(treasureValues, treasureCoords, new FakeCluesSetter());	
		CaseMapFactory mapFactory = new TxtFileCaseMapFactory(null);

		treasureQuestGameFactory.newGame(mapFactory.load(ALL_TYPES_MAP));
		TreasureQuestGame game = treasureQuestGameFactory.getGame();

		assertEquals(1, game.getTreasureCount());
	}
	
	@Test
	void it_creates_new_games_from_map_fragment() {
		IntSequence treasureValues = new FakeIntSequence(4);
		var treasureCoords = new FakeCoordinatesSequence(Coordinates.ofRowAndCol(1, 0));
		TreasureQuestGameFactory treasureQuestGameFactory = new TreasureQuestGameFactory(treasureValues, treasureCoords, new FakeCluesSetter());	
		CaseMapFactory mapFactory = new TxtFileCaseMapFactory(new FakeIntSequence(1,1));
		

	    treasureQuestGameFactory.newGame(mapFactory.load(BIGGER_MAP, 3));
	    TreasureQuestGame game = treasureQuestGameFactory.getGame();

		assertEquals(1, game.getTreasureCount());
	}

	
	
}
