package treasurequest.domains;

import java.util.HashMap;
import java.util.Map;

/**
 * Cette classe construit des cartes pour les tests unitaires.
 * 
 */
class CaseMapTestData {
	static CaseMap sample1() {
		char[][] casesTable = {
				{ 'E', 'S', 'E' },
				{ 'F', 'R', 'P' },
				{ 'E', 'S', 'E' }
		};
		
		return caseMapOfTable(casesTable);
	}

	static CaseMap sample2() {
		char[][] casesTable = { 
				{ 'F', 'F', 'P', 'P', 'P', 'P', 'P', 'E', 'E' },
				{ 'F', 'F', 'P', 'P', 'P', 'P', 'E', 'E', 'E' }, 
				{ 'P', 'P', 'P', 'E', 'E', 'E', 'E', 'E', 'E' },
				{ 'P', 'P', 'E', 'E', 'S', 'S', 'S', 'S', 'S' }, 
				{ 'E', 'E', 'E', 'E', 'S', 'P', 'P', 'P', 'P' },
				{ 'E', 'E', 'E', 'E', 'S', 'P', 'P', 'P', 'P' }, 
				{ 'E', 'E', 'E', 'E', 'S', 'S', 'S', 'S', 'S' },
				{ 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E' }, 
				{ 'R', 'R', 'E', 'E', 'E', 'E', 'E', 'E', 'E' } };

		return caseMapOfTable(casesTable);
	}

	private static CaseMap caseMapOfTable(char[][] data) {
		Map<Coordinates, Case> cases = new HashMap<>(81);
		for (int row = 0; row < data.length; ++row) {
			for (int col = 0; col < data[row].length; ++col) {

				cases.put(Coordinates.ofRowAndCol(row, col), mapToCase(data[row][col]));
			}
		}

		return CaseMap.ofPairs(cases);
	}

	private static Case mapToCase(char c) {
		switch (c) {
		case 'S':
			return Case.ofType(CaseType.SAND);
		case 'P':
			return Case.ofType(CaseType.GRASSLAND);
		case 'F':
			return Case.ofType(CaseType.FOREST);
		case 'R':
			return Case.ofType(CaseType.ROCK);
		default:
			return Case.ofType(CaseType.WATER);
		}
	}
}
