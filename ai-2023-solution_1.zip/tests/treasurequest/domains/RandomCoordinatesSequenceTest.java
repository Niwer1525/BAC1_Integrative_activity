package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import org.junit.jupiter.api.Test;

class RandomCoordinatesSequenceTest {

	@Test
	void it_returns_provided_coordinates_in_a_random_way() {
		var givenCoords = List.of(
			Coordinates.ofRowAndCol(4, 2),
			Coordinates.ofRowAndCol(2, 4),
			Coordinates.ofRowAndCol(3, 1)
		);
		
		var  randomGenerator = new RandomCoordinatesSequence();
		randomGenerator.setSelectableCoords(givenCoords);
		
		var actualCoords = new LinkedHashSet<>();
		for(int i=0; i <givenCoords.size(); ++i) {
			actualCoords.add(randomGenerator.next());
		}
		
		assertEquals(actualCoords.size(), givenCoords.size());
		assertTrue(givenCoords.containsAll(actualCoords));		
		assertIterableNotEquals(givenCoords, actualCoords);
	}

	private void assertIterableNotEquals(List<Coordinates> givenCoords, LinkedHashSet<Object> actualCoords) {
		int misplacedCoordsCount = 0;
		int pos = 0;
		for(var actualCoord : actualCoords) {
			int givenPos = givenCoords.indexOf(actualCoord);
			if(givenPos != pos) {
				++misplacedCoordsCount;
			}
		}
		
		assertNotEquals(0, misplacedCoordsCount);
	}

}
