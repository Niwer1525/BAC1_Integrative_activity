package treasurequest.domains;

import java.util.*;

/**
 * Crée une séquence de coordonnées où les valeurs sont connues d'avance.
 * */
public class FakeCoordinatesSequence implements CoordinatesSequence {

	private final List<Coordinates> source;
	private int pos;

	public FakeCoordinatesSequence(Coordinates...cols) {
		this.source = Arrays.asList(cols);
	}

	@Override
	public void setSelectableCoords(Collection<Coordinates> coordinates) {
		this.pos = 0;
	}

	@Override
	public Coordinates next() {
		var next = source.get(pos);
		pos = (pos + 1)%source.size();
		
		return next;
	}

}
