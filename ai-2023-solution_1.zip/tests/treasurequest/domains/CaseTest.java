package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CaseTest {

    @Test
    void it_inits_from_a_case_type() {
        var newCase = Case.ofType(CaseType.GRASSLAND);
        
        assertEquals(CaseType.GRASSLAND, newCase.getCaseType());
        assertEquals(0, newCase.getAmount());
        assertEquals(Orientation.NONE, newCase.getClue());
        assertEquals(CaseType.GRASSLAND.getCost(), newCase.getDigCost());
        assertTrue(newCase.canBeDug());
    }
    
    @Test
    void it_tells_if_it_is_diggable() {
    	var diggable = Case.ofType(CaseType.GRASSLAND);
    	var waterCase = Case.ofType(CaseType.WATER);
    	
    	assertTrue(diggable.isDiggable());
    	assertFalse(waterCase.isDiggable());
    	assertFalse(Case.UNKOWN.isDiggable());
    }
    
    @Test
    void it_tells_if_it_is_diggable_for_a_given_amount() {
    	var diggable = Case.ofType(CaseType.GRASSLAND);
    	var waterCase = Case.ofType(CaseType.WATER);
    	
    	assertTrue(diggable.isDiggableFor(10));
    	assertTrue(diggable.isDiggableFor(2));
    	assertFalse(diggable.isDiggableFor(1));
    	
    	assertFalse(waterCase.isDiggableFor(10));
    	assertFalse(waterCase.isDiggableFor(2));
    	assertFalse(waterCase.isDiggableFor(1));
    }

    @Test
    void it_sets_amounts() {
        var newCase = Case.ofType(CaseType.ROCK);
        
        newCase.setAmount(20);
        
        assertEquals(CaseType.ROCK, newCase.getCaseType());
        assertEquals(20, newCase.getAmount());
        assertEquals(Orientation.NONE, newCase.getClue());
        assertEquals(CaseType.ROCK.getCost(), newCase.getDigCost());
        assertTrue(newCase.canBeDug());
    }
    
    @Test
    void it_ignores_negative_amount() {
        var newCase = Case.ofType(CaseType.ROCK);
        
        newCase.setAmount(-20);
        
        assertEquals(CaseType.ROCK, newCase.getCaseType());
        assertEquals(0, newCase.getAmount());
        assertEquals(Orientation.NONE, newCase.getClue());
        assertEquals(CaseType.ROCK.getCost(), newCase.getDigCost());
        assertTrue(newCase.canBeDug());
    }
    
    @Test
    void it_ignores_amount_when_it_is_undiggable() {
    	var newCase = Case.ofType(CaseType.WATER);
    	
    	newCase.setAmount(13);
    	
        assertEquals(CaseType.WATER, newCase.getCaseType());
        assertEquals(0, newCase.getAmount());
        assertEquals(Orientation.NONE, newCase.getClue());
        assertEquals(CaseType.WATER.getCost(), newCase.getDigCost());
        assertFalse(newCase.canBeDug());
    }
    
    @Test
    void it_ignores_amount_when_it_has_an_orientation() {
        var newCase = Case.ofType(CaseType.ROCK);
        newCase.setClue(Orientation.SOUTH);
        
        newCase.setAmount(10);
        
        assertEquals(0, newCase.getAmount());
    }
    
    @Test
    void it_digs_when_diggable() {
        var newCase = Case.ofType(CaseType.SAND);        
        newCase.setAmount(15);
        
        newCase.setDug();
        
        assertFalse(newCase.canBeDug());
    }
    
    @Test
    void it_ignores_dig_command_when_undiggable() {
    	var newCase = Case.ofType(CaseType.WATER);
    	
        newCase.setDug();
        
        assertFalse(newCase.canBeDug());
    }

    @Test
    void it_sets_clue_when_diggable_and_no_amount_set() {
    	var newCase = Case.ofType(CaseType.SAND);
    	
    	newCase.setClue(Orientation.NORTH);
    	
    	assertEquals(Orientation.NORTH, newCase.getClue());
    }
    
    @Test
    void it_ignores_clue_set_when_diggable_and_amount_set() {
    	var newCase = Case.ofType(CaseType.SAND);
    	newCase.setAmount(10);
    	
    	newCase.setClue(Orientation.NORTH);
    	
    	assertEquals(Orientation.NONE, newCase.getClue());
    }
    
    @Test
    void it_ignores_clue_set_when_undiggable() {
    	var newCase = Case.ofType(CaseType.WATER);
    	
    	newCase.setClue(Orientation.NORTH);
    	
    	assertEquals(Orientation.NONE, newCase.getClue());
    }
}
