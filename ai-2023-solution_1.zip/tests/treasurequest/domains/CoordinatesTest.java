package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;
import static treasurequest.domains.Coordinates.ORIGIN;

import org.junit.jupiter.api.Test;


class CoordinatesTest {

	@Test
	void it_makes_coords_of_rows_and_cols() {
		var coord = Coordinates.ofRowAndCol(4, 2);
		
		assertEquals(4, coord.getRow());
		assertEquals(2, coord.getCol());
	}
	
	@Test
	void it_computes_distance_between_a_target_coord() {
		var coord1 = Coordinates.ofRowAndCol(4, 2);
		var coord2 = Coordinates.ofRowAndCol(2, 4);
		
		assertEquals(4.47, coord1.getDistanceTo(ORIGIN), 0.01);
		assertEquals(4.47, coord2.getDistanceTo(ORIGIN), 0.01);
		assertEquals(2.82, coord1.getDistanceTo(coord2),0.01);
		assertEquals(2.82, coord2.getDistanceTo(coord1),0.01);
		assertEquals(Double.NaN, coord1.getDistanceTo(null));
	}
	
	@Test
	void it_returns_movement_result() {
		var coord2 = Coordinates.ofRowAndCol(2, 4);
		
		var result = coord2.plus(1, -1);
		
		assertNotSame(coord2, result);
		assertEquals(3, result.getRow());
		assertEquals(3, result.getCol());
	}
	
	@Test
	void it_gets_orientation_to_another_coordinates() {	
		assertEquals(Orientation.NORTH_WEST, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(-1, -1)));
		assertEquals(Orientation.NORTH, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(-1, 0)));
		assertEquals(Orientation.NORTH_EAST, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(-1, 1)));
		assertEquals(Orientation.WEST, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(0, -1)));
		assertEquals(Orientation.NONE, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(0, 0)));
		assertEquals(Orientation.EAST, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(0, 1)));
		assertEquals(Orientation.SOUTH, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(1, 0)));
		assertEquals(Orientation.SOUTH_EAST, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(1, 1)));
		assertEquals(Orientation.SOUTH_WEST, ORIGIN.getOrientationTo(Coordinates.ofRowAndCol(1, -1)));
	}
	
	@Test
	void it_has_a_string_representation() {
		assertEquals("Coordinates(0, 0)", ORIGIN.toString());
		assertEquals("Coordinates(4, 2)", Coordinates.ofRowAndCol(4,2).toString());
	}
	
	@Test
	void it_is_equatable() {
		var coord1 = Coordinates.ofRowAndCol(4, 2);
		var coord1Clone = Coordinates.ofRowAndCol(4, 2);	
		var coord2 = Coordinates.ofRowAndCol(2, 4);
		var coord3 = Coordinates.ofRowAndCol(5, 2);
		
		
		assertEquals(coord1, coord1);
		assertEquals(coord1, coord1Clone);
		assertEquals(coord1Clone, coord1);
		
		assertNotEquals(coord1, coord2);
		assertNotEquals(coord1, coord3);
		assertNotEquals(coord2, coord1);
		assertNotEquals(coord2, coord1Clone);
		assertNotEquals(coord2, null);
	}
	
	@Test
	void its_hashcode_is_consistent_with_equals() {
		var coord1 = Coordinates.ofRowAndCol(4, 2);
		var coord1Clone = Coordinates.ofRowAndCol(4, 2);
		
		assertEquals(coord1.hashCode(), coord1Clone.hashCode());
	}
	
	@Test
	void it_is_comparables_to_another_coordinate() {
		var coord1 = Coordinates.ofRowAndCol(4, 2);	
		var coord2 = Coordinates.ofRowAndCol(2, 4);
		var coord3 = Coordinates.ofRowAndCol(5, 2);
		
		assertEquals(1, coord1.compareTo(coord2)); //same distance but different due to angle
		assertEquals(-1, coord2.compareTo(coord1)); //same distance but different due to angle
		
		assertEquals(-1, coord1.compareTo(coord3));
		assertEquals(1, coord3.compareTo(coord1));
		
		assertEquals(0, coord1.compareTo(Coordinates.ofRowAndCol(4, 2)));
	}

}
