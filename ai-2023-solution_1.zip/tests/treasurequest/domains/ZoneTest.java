package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ZoneTest {
	@Test
	void it_has_an_empty_zone_constant() {
		//Empty constant
		assertEquals(CaseType.UNKNOWN, Zone.EMPTY.getType());
		assertEquals(0, Zone.EMPTY.getSize());
	}
	
	@Test
	void it_inits_with_coords_and_case_type() {
		Zone zone = new Zone(Coordinates.ORIGIN, CaseType.SAND);
		
		assertEquals(CaseType.SAND, zone.getType());
		assertEquals(1, zone.getSize());
	}
	
	@Test
	void it_accepts_new_coords() {
		Zone zone = new Zone(Coordinates.ORIGIN, CaseType.FOREST);
		
		zone.add(Coordinates.ofRowAndCol(1, 0));
		
		assertEquals(CaseType.FOREST, zone.getType());
		assertEquals(2, zone.getSize());
	}
	
	@Test
	void it_tells_if_it_has_a_given_type() {
		Zone forestZone = new Zone(Coordinates.ORIGIN, CaseType.FOREST);
		Zone sandZone = new Zone(Coordinates.ORIGIN, CaseType.SAND);
		
		assertTrue(forestZone.hasSameType(CaseType.FOREST));
		assertFalse(forestZone.hasSameType(CaseType.SAND));
		assertFalse(forestZone.hasSameType(CaseType.ROCK));
		
		assertFalse(sandZone.hasSameType(CaseType.FOREST));
		assertTrue(sandZone.hasSameType(CaseType.SAND));
		assertFalse(sandZone.hasSameType(CaseType.ROCK));
	}
	
	@Test
	void it_returns_the_largest_zone_between_itself_and_another_zone() {
		Zone forestZone = new Zone(Coordinates.ORIGIN, CaseType.FOREST);
		Zone rockZone = new Zone(Coordinates.ORIGIN, CaseType.ROCK);
		Zone sandZone = new Zone(Coordinates.ORIGIN, CaseType.SAND);
		sandZone.add(Coordinates.ofRowAndCol(1, 0));
		
		assertEquals(sandZone, forestZone.largestBetween(sandZone));
		assertEquals(sandZone, sandZone.largestBetween(forestZone));
		//gestion du cas null
		assertEquals(forestZone, forestZone.largestBetween(null));
		//gestion de l'égalité
		assertEquals(rockZone, rockZone.largestBetween(forestZone));
		assertEquals(forestZone, forestZone.largestBetween(rockZone));
	}
}
