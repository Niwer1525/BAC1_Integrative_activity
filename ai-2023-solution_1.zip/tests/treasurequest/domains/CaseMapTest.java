package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.*;

class CaseMapTest {
	
	@Test
	void it_makes_single_map() {
		var map =  CaseMap.single();
		
		assertIterableEquals(Set.of(Coordinates.ORIGIN), map);
		assertEquals(CaseType.SAND, map.getCaseTypeAt(Coordinates.ORIGIN));
	}
	
	@Test
	void it_returns_single_map_on_null_or_empty_pairs() {
		var emptyMap = CaseMap.ofPairs(Map.of());
		var nullMap = CaseMap.ofPairs(null);
		
		assertIterableEquals(Set.of(Coordinates.ORIGIN), emptyMap);
		assertIterableEquals(Set.of(Coordinates.ORIGIN), nullMap);
	}

	@Test
	void it_computes_mass_center_coords() {
		var map = CaseMapTestData.sample1();

		Coordinates center = map.getCenter();

		assertEquals(coord(1, 1), center);
	}

	@Test
	void it_iterates_trough_coords() {
		var map = CaseMapTestData.sample1();

		var expectedCoords = Set.of(
				coord(0, 0), coord(0, 1), coord(0, 2),
				coord(1, 0), coord(1, 1), coord(1, 2),
				coord(2, 0), coord(2, 1), coord(2, 2));

		assertIterableEquals(expectedCoords, map);
	}

	@Test
	void it_returns_data_about_a_given_case() {
		var map = CaseMapTestData.sample1();
		var centralCoord = coord(1,1);
		
		assertEquals(CaseType.ROCK, map.getCaseTypeAt(centralCoord));
		assertEquals(5, map.getCaseCostAt(centralCoord));
		assertEquals(0, map.getTreasureAt(centralCoord));
		assertEquals(Orientation.NONE, map.getClueAt(centralCoord));
	}

	@Test
	void it_knows_diggable_coords() {
		var map = CaseMapTestData.sample1();

		var actual = map.getDiggableCoords();

		assertEquals(5, actual.size());
		assertTrue(actual.contains(coord(0, 1)));
		assertTrue(actual.contains(coord(1, 0)));
		assertTrue(actual.contains(coord(1, 1)));
		assertTrue(actual.contains(coord(1, 2)));
		assertTrue(actual.contains(coord(2, 1)));
	}

	@Test
	void it_sets_amounts_on_a_given_case() {
		var map = CaseMapTestData.sample1();

		map.setAmountAt(10, coord(0, 1));

		assertEquals(10, map.getTreasureAt(coord(0, 1)));
	}

	@Test
	void it_sets_clue_on_a_given_case() {
		var map = CaseMapTestData.sample1();

		map.setClueAt(Orientation.WEST, coord(1, 1));

		assertEquals(Orientation.WEST, map.getClueAt(coord(1, 1)));
	}
	
	@Test
	void it_ignores_unknown_coords() {
		var map = CaseMapTestData.sample1();
		
		var unknownCoord = coord(-1, -1);
		map.setAmountAt(10, unknownCoord);
		
		assertEquals(CaseType.UNKNOWN, map.getCaseTypeAt(unknownCoord));
		assertEquals(0, map.getCaseCostAt(unknownCoord));
		assertEquals(0, map.getTreasureAt(unknownCoord));
		
	}
	
	@Test
	void it_tells_whether_a_case_is_diggable_for_a_given_amount() {
		var map = CaseMapTestData.sample1();
		
		assertTrue(map.isDiggableFor(1, coord(0,1)));
		assertTrue(map.isDiggableFor(5, coord(1,1)));
		assertTrue(map.isDiggableFor(2, coord(1,2)));
		assertTrue(map.isDiggableFor(3, coord(1,0)));
		
		assertFalse(map.isDiggableFor(0, coord(0,1)));
		assertFalse(map.isDiggableFor(4, coord(1,1)));
		assertFalse(map.isDiggableFor(1, coord(1,2)));
		assertFalse(map.isDiggableFor(2, coord(1,0)));
	}

	@Test
	void it_counts_affordable_cases_for_a_given_amount() {
		var map = CaseMapTestData.sample1();
		
		assertEquals(5, map.countDiggableCaseFor(5));
		assertEquals(4, map.countDiggableCaseFor(4));
		assertEquals(3, map.countDiggableCaseFor(2));
		assertEquals(2, map.countDiggableCaseFor(1));
		assertEquals(0, map.countDiggableCaseFor(0));
	}
	
	@Test
	void it_counts_treasures_left() {
		var map = CaseMapTestData.sample1();

		map.setAmountAt(10, coord(1, 0));
		map.setAmountAt(10, coord(1, 2));
		
		assertEquals(2, map.countTreasureLeft());
	}
	
	@Test
	void it_digs_given_cases() {
		var map = CaseMapTestData.sample1();
		map.setAmountAt(10, coord(1, 0));
		map.setAmountAt(10, coord(1, 2));
		
		map.digAt(coord(1, 2));
		
		assertEquals(1, map.countTreasureLeft());
	}
	
	@Test
	void it_tells_if_a_given_case_is_diggable_and_empty() {
		var map = CaseMapTestData.sample1();
		map.setAmountAt(10, coord(1, 0));
		
		assertTrue(map.isDiggableAndEmpty(coord(0,1)));
		assertTrue(map.isDiggableAndEmpty(coord(1,1)));
		assertTrue(map.isDiggableAndEmpty(coord(1,2)));
		
		assertFalse(map.isDiggableAndEmpty(coord(1,0)));
		assertFalse(map.isDiggableAndEmpty(coord(0,0)));
	}
	
	@Test
	void it_returns_a_list_of_treasure_coords_around_a_given_coord() {
		var map = sample2WithTreasures();
		
		var treasureCoords = new TreeSet<>(map.getTreasuresAround(coord(4, 4)));
		assertIterableEquals(List.of(coord(2,2), coord(5, 4), coord(5, 6)), treasureCoords);
	
		var emptyCoords = map.getTreasuresAround(coord(8,0));
		assertTrue(emptyCoords.isEmpty());
	}
	
	/**
	 * Méthode utilitaire retournant de nouvelles coordonnées.
	 * */
	private Coordinates coord(int row, int col) {
		return Coordinates.ofRowAndCol(row, col);
	}
	
	private CaseMap sample2WithTreasures() {
		var newMap = CaseMapTestData.sample2();
		
		newMap.setAmountAt(12, Coordinates.ofRowAndCol(0, 4));
		newMap.setAmountAt(10, Coordinates.ofRowAndCol(2, 0));
		newMap.setAmountAt(10, Coordinates.ofRowAndCol(2, 2));
		newMap.setAmountAt(20, Coordinates.ofRowAndCol(5, 4));
		newMap.setAmountAt(20, Coordinates.ofRowAndCol(5, 6));
		
		
		return newMap;
	}
	
}
