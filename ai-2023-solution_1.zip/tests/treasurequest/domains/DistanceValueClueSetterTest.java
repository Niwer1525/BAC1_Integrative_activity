package treasurequest.domains;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

class DistanceValueClueSetterTest {

	@Test
	void it_sets_clues_on_a_map_filled_with_treasures() {
		var sample1 = sample1WithTreasures();
		var clueSetter = new DistanceValueClueSetter();

		clueSetter.setClues(sample1);

		assertEquals(Orientation.SOUTH_EAST, sample1.getClueAt(Coordinates.ofRowAndCol(0, 1)));
		assertEquals(Orientation.EAST, sample1.getClueAt(Coordinates.ofRowAndCol(1, 1)));
		assertEquals(Orientation.EAST, sample1.getClueAt(Coordinates.ofRowAndCol(1, 0)));
		assertEquals(Orientation.NORTH_EAST, sample1.getClueAt(Coordinates.ofRowAndCol(2, 1)));
	}
	
	@Test
	void it_sets_no_orientation_for_water_cases() {
		var sample1 = sample1WithTreasures();
		var clueSetter = new DistanceValueClueSetter();

		clueSetter.setClues(sample1);
		
		assertEquals(Orientation.NONE, sample1.getClueAt(Coordinates.ORIGIN));
	}

	@Test
	void it_sets_no_clue_on_a_map_without_treasures() {
		var sample1 = CaseMapTestData.sample1();
		var clueSetter = new DistanceValueClueSetter();
		
		clueSetter.setClues(sample1);
		
		assertEquals(Orientation.NONE, sample1.getClueAt(Coordinates.ofRowAndCol(0, 1)));
		assertEquals(Orientation.NONE, sample1.getClueAt(Coordinates.ofRowAndCol(1, 1)));
		assertEquals(Orientation.NONE, sample1.getClueAt(Coordinates.ofRowAndCol(1, 0)));
		assertEquals(Orientation.NONE, sample1.getClueAt(Coordinates.ofRowAndCol(2, 1)));
	}
	
	@Test
	void it_favors_closest_distance_when_many_treasures_are_found() {
		var caseMap = sample2WithTreasures();
		var clueSetter = new DistanceValueClueSetter();
	
		clueSetter.setClues(caseMap);
		
		assertEquals(Orientation.SOUTH, caseMap.getClueAt(Coordinates.ofRowAndCol(1, 2)));
	}
	
	@Test
	void it_favors_treasure_of_bigger_values_when_same_distance_conflict() {
		var caseMap = sample2WithTreasures();
		var clueSetter = new DistanceValueClueSetter();
	
		clueSetter.setClues(caseMap);
		
		assertEquals(Orientation.EAST, caseMap.getClueAt(Coordinates.ofRowAndCol(0, 2)));
	}
	
	@Test
	void it_favors_treasures_closer_to_the_origin_when_same_value_conflicts() {
		var caseMap = sample2WithTreasures();
		var clueSetter = new DistanceValueClueSetter();
	
		clueSetter.setClues(caseMap);
		
		assertEquals(Orientation.NORTH_WEST, caseMap.getClueAt(Coordinates.ofRowAndCol(3, 1)));
	}
	
	private CaseMap sample1WithTreasures() {
		var sampleMap = CaseMapTestData.sample1();
		
		sampleMap.setAmountAt(15, Coordinates.ofRowAndCol(1, 2));
		
		return sampleMap;
	}
	
	private CaseMap sample2WithTreasures() {
		var newMap = CaseMapTestData.sample2();
		
		newMap.setAmountAt(12, Coordinates.ofRowAndCol(0, 4));
		newMap.setAmountAt(10, Coordinates.ofRowAndCol(2, 0));
		newMap.setAmountAt(10, Coordinates.ofRowAndCol(2, 2));
		newMap.setAmountAt(20, Coordinates.ofRowAndCol(5, 4));
		newMap.setAmountAt(20, Coordinates.ofRowAndCol(5, 6));
		
		
		return newMap;
	}
}
