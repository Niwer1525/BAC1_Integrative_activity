package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseTypeTest {

	@Test
	void it_has_a_cost() {
		
		assertEquals(0, CaseType.WATER.getCost());
		assertEquals(1, CaseType.SAND.getCost());
		assertEquals(2, CaseType.GRASSLAND.getCost());
		assertEquals(3, CaseType.FOREST.getCost());
		assertEquals(5, CaseType.ROCK.getCost());
		assertEquals(0, CaseType.UNKNOWN.getCost());
	}

}
