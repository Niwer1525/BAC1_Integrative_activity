package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

import org.junit.jupiter.api.*;

class TreasureQuestGameTest {
    private TreasureQuestGameFactory factory;

    @BeforeEach
	void setup() {
		factory = new TreasureQuestGameFactory(
				new FakeIntSequence(15), 
				new FakeCoordinatesSequence(Coordinates.ofRowAndCol(1, 2)),
				new DistanceValueClueSetter()
			);
	}

	@Test
    void it_starts_by_given_the_player_coins_and_a_position() {  	
    	var game = gameWithSample1();
    	
    	game.start(0);
    	
    	assertFalse(game.isOver());
    	assertEquals(2, game.getPlayerCoins());
    	assertEquals(Coordinates.ofRowAndCol(1, 1), game.getActiveCase());
    }
    
    @Test
    void it_tells_about_the_game_state() {
    	var game = gameWithSample1();
    	
    	game.start(0);
		    	
    	assertEquals(1, game.getTreasureCount());
		assertEquals(2, game.getPlayerCoins());
		assertEquals(Coordinates.ofRowAndCol(1, 1), game.getActiveCase());
		assertEquals(CaseType.ROCK, game.getActiveCaseType());
		assertEquals(5, game.getActiveCaseCost());
    }
    
    @Test
    void it_provides_its_casemap() {
    	var game = gameWithSample1();
    	
    	var caseMap = game.getCaseMap();
    	
    	assertNotNull(caseMap);
    	assertEquals(1, caseMap.countTreasureLeft());
    	assertEquals(5, caseMap.countDiggableCaseFor(10));
    }
    
    @Test
    void it_moves_the_player() {
    	var game = gameWithSample1();
    	
    	game.start(0);
    	game.move(-1, 0);
    	
    	assertEquals(Coordinates.ofRowAndCol(0, 1), game.getActiveCase());
		assertEquals(CaseType.SAND, game.getActiveCaseType());
		assertEquals(1, game.getActiveCaseCost());
    }
    
    @Test
    void it_ignores_move_when_it_goes_to_unknown_cases() {
    	var game = gameWithSample1();
    	
    	game.start(0);
    	game.move(2, 0); //move to a water case
    	
		assertEquals(Coordinates.ofRowAndCol(1, 1), game.getActiveCase());
		assertEquals(CaseType.ROCK, game.getActiveCaseType());
		assertEquals(5, game.getActiveCaseCost());
    }

    @Test
    void it_returns_clue_found_when_digging_a_case_with_treasure() {
    	var game = gameWithSample1();
    	game.start(0);
    	
    	game.move(-1, 0);//digging a sand case
    	DigResult actual = game.dig();
    	
    	assertEquals(DigResult.CLUE_FOUND, actual);
    	assertEquals(1, game.getPlayerCoins());
    }
    
    @Test
    void it_returns_nothing_found_for_empty_cases() {
    	var game = gameWithSample2();
    	game.start(0);
    	
    	game.move(0, 5);
    	var result = game.dig();
    	
    	assertEquals(DigResult.NOTHING, result);    	
    }
    
    @Test
    void it_returns_treasure_found_when_digging_a_case_with_treasure() {
    	var game = gameWithSample1();
    	game.start(0);
    	
    	game.move(0, 1);//digging treasure
    	DigResult actual = game.dig();
    	
    	assertEquals(DigResult.TREASURE_FOUND, actual);
    	assertEquals(2 - 2 +15, game.getPlayerCoins());
    }
    
    @Test
    void it_cannot_dig_an_already_dug_case() {
    	var game = gameWithSample1();
    	game.start(0);
    	
    	game.move(-1, 0);//digging a sand case
    	DigResult firstDug = game.dig();
    	DigResult secondDug = game.dig();
    	
    	assertNotEquals(DigResult.UNDIGGABLE, firstDug);
    	assertEquals(DigResult.UNDIGGABLE, secondDug);
    }
    
    @Test
    void it_tells_game_is_over_when_all_treasures_are_found() {
    	var game = gameWithSample1();
    	game.start(0);
    	
    	game.move(0, 1);//digging treasure
    	game.dig();
    	
    	assertTrue(game.isOver());
    }
    
    @Test
    void it_is_over_when_no_affordable_cases_left() {
    	var game = gameWithSample1();
    	game.start(0);
    	
    	game.move(-1, 0);//digging sand once
    	game.dig();
    	game.move(2, 0);//digging sand twice
    	game.dig();
    	
    	assertTrue(game.isOver());
    }
    
    @Test
    void it_updates_players_game_time() {
    	var game = gameWithSample1();
    	game.start(0);
    	
    	game.setEndTime(1000);
    	
    	var player = factory.getPlayer();
    	assertEquals(Duration.ofSeconds(1), player.getGameTime());
    }
    
	private TreasureQuestGame gameWithSample1() {
		factory.newGame(CaseMapTestData.sample1());
		
		return factory.getGame();
	}
	
	private TreasureQuestGame gameWithSample2() {
		factory.newGame(CaseMapTestData.sample2());
		
		return factory.getGame();
	}
    	   
}
