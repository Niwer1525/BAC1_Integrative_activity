package treasurequest.domains;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TxtFileCaseMapFactoryTest {

    private static final String DEFAULT_TEST_MAP = "resources/maps/map-test-1.txt";
    private static final String UNPLAYABLE_TEST_MAP = "resources/maps/map-test-2.txt";
    private static final String ALL_TYPES_MAP = "resources/maps/map-test-3.txt";
    
	private CaseMapFactory factory;

    @BeforeEach
    public void setup() {
    	 factory = new TxtFileCaseMapFactory(new FakeIntSequence(2,3));
    }
    
    @Test
    void it_creates_a_map_from_a_file() {
        var map = factory.load(DEFAULT_TEST_MAP);
        int caseCount = 0;
        for(var coords : map) {
        	assertNotNull(coords);
        	++caseCount;
        }
        
        assertEquals(30, caseCount);
    }
    
    @Test
    void it_returns_the_singleton_map_when_null_file_path() {
        assertIterableEquals(List.of(Coordinates.ORIGIN), factory.load(null));
        assertIterableEquals(List.of(Coordinates.ORIGIN), factory.load(null, 3));
    }
    
    @Test
    void it_returns_the_singleton_map_when_unplayable_map() {
        assertIterableEquals(List.of(Coordinates.ORIGIN), factory.load(UNPLAYABLE_TEST_MAP));
        assertIterableEquals(List.of(Coordinates.ORIGIN), factory.load(UNPLAYABLE_TEST_MAP, 2));
    }

    @Test
    void it_maps_all_kinds_of_cases() {
        var map = factory.load(ALL_TYPES_MAP);
        
        assertEquals(0, map.getCaseCostAt(Coordinates.ORIGIN));
        assertEquals(3, map.getCaseCostAt(Coordinates.ofRowAndCol(0,1)));
        assertEquals(1, map.getCaseCostAt(Coordinates.ofRowAndCol(1,0)));
        assertEquals(5, map.getCaseCostAt(Coordinates.ofRowAndCol(1,1)));
        assertEquals(2, map.getCaseCostAt(Coordinates.ofRowAndCol(1,2)));
        assertEquals(2, map.getCaseCostAt(Coordinates.ofRowAndCol(2,1)));
    }
   
    @Test
    void it_extracts_submap_from_bigger_map() {
    	var map = factory.load(DEFAULT_TEST_MAP, 3);
    	
        assertEquals(5, map.getCaseCostAt(Coordinates.ORIGIN));
        assertEquals(2, map.getCaseCostAt(Coordinates.ofRowAndCol(0,1)));
        assertEquals(0, map.getCaseCostAt(Coordinates.ofRowAndCol(0,2)));
        
        assertEquals(2, map.getCaseCostAt(Coordinates.ofRowAndCol(1,0)));
        assertEquals(2, map.getCaseCostAt(Coordinates.ofRowAndCol(1,1)));
        assertEquals(0, map.getCaseCostAt(Coordinates.ofRowAndCol(1,2)));
        
        assertEquals(0, map.getCaseCostAt(Coordinates.ofRowAndCol(2,0)));
        assertEquals(0, map.getCaseCostAt(Coordinates.ofRowAndCol(2,2)));
        assertEquals(0, map.getCaseCostAt(Coordinates.ofRowAndCol(2,1)));
    }
}
