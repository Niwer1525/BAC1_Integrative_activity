package treasurequest.domains;

/**
 * Gère une séquence d'entier où les valeurs sont connues d'avance.
 * */
class FakeIntSequence implements IntSequence {
	private final int[] values;
	private int pos;

	public FakeIntSequence(int ...values) {
		this.values = values.length > 0 ? values : new int[] { 10 };
		this.pos = 0;
	}
	
	@Override
	public int nextBetween(int min, int max) {
		int next = values[pos];
		pos = (pos + 1)%values.length;
		
		return next;
	} 
}
