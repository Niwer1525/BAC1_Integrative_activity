package treasurequest.io;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class CharArrayFileReaderTest {
	@Test
	public void mapsFileContentToCharArray() {
		char[][] expected = new char[][] {
			{'X','F','X'},
			{'S','R','P'},
			{'X','P','X'},			
		};
		
		char[][] actual = CharArrayFileReader.parseFile("resources/maps/map-test-3.txt");
		
		
		assertEquals(expected.length, actual.length, "Expecting same length");
		for(int pos = 0; pos < expected.length; ++pos) {
			assertArrayEquals(expected[pos], actual[pos], String.format("at line %d", pos));
		}
	}
	
	@Test
	public void throwsExceptionWhenPathDoesNotMatchAnExistingFile() {
		assertThrows(RuntimeException.class, () -> CharArrayFileReader.parseFile("resources/maps/unexisting-file.txt"));
	}
}
