package treasurequest.supervisors;

import java.util.Map;
import static java.util.Map.entry;


import treasurequest.domains.*;
import treasurequest.supervisors.views.*;

/**
 * Réagit aux événements utilisateurs de sa vue en mettant à jour une partie en
 * cours et fournit à sa vue les données à afficher.
 */
public class PlayGameSupervisor {
	private final GameProvider gameProvider;
	private PlayGameView view;
	private TreasureQuestGame game;
	
	private final Map<Orientation, SpriteType> orient2Sprite = Map.ofEntries(
			entry(Orientation.SOUTH, SpriteType.SOUTH),
			entry(Orientation.SOUTH_EAST, SpriteType.SOUTH_EAST),
			entry(Orientation.SOUTH_WEST, SpriteType.SOUTH_WEST),
			entry(Orientation.NORTH, SpriteType.NORTH),
			entry(Orientation.NORTH_EAST, SpriteType.NORTH_EAST),
			entry(Orientation.NORTH_WEST, SpriteType.NORTH_WEST),
			entry(Orientation.EAST, SpriteType.EAST),
			entry(Orientation.WEST, SpriteType.WEST)
			);

	/**
	 * Construit un superviseur de partie à l'aide d'un fournisseur de jeu.
	 */
	public PlayGameSupervisor(GameProvider gameProvider) {
		this.gameProvider = gameProvider;
	}

	/**
	 * Définit la vue de ce superviseur à {@code view}.
	 */
	public void setView(PlayGameView view) {
		if (view == null) {
			return;
		}
		this.view = view;
	}

	/**
	 * Méthode appelée juste avant que la vue de ce superviseur soit affichée à
	 * l'écran.
	 * 
	 * Le superviseur affiche les données de départ du jeu (cout de la case active,
	 * nombre de trésors, bourse du joueur, etc.). Il dessine également les cases et
	 * indique quelle case est active.
	 */
	/*
	 * Post-conditions après le début de la partie
	 * ============================================
	 * 
	 * - La bourse du joueur doit être >= C (c-à-d 1 pièce d'or dans le cas de
	 * l'itération 1) sinon il ne sait rien faire. - La carte compte au moins une
	 * case de type sable, pour que le joueur sache la creuser. - La carte compte un
	 * nombre de trésors = à 10% du nombre de cases creusables, arrondi à l'entier
	 * supérieur (ce qui garantit un minimum de 1 trésor). - Le type d'une case est
	 * sable, prairie, foret, roche, ou eau. Elle n'est pas creusée. Le trésor
	 * qu'elle contient est soit = 0, soit compris entre 10 et 20 pièces inclus. -
	 * Toutes les cases de type eau possèdent 0 pièce.
	 */

	public void onEnter(String fromView) {
		if (ViewNames.MAIN_MENU.equals(fromView)) {
			game = gameProvider.getGame();
			game.start(System.currentTimeMillis());

			displayMap(game.getCaseMap());
			moveActiveCase(game.getActiveCase());
			updateOverlay();
		}
	}

	private void updateOverlay() {
		view.setPlayerCoins("Bourse du joueur : " + game.getPlayerCoins() + " P");
		view.setTreasuresCount("Trésors restants : " + game.getTreasureCount());
		updateActiveCaseOverlay();

	}

	private void updateActiveCaseOverlay() {
		view.setActiveCaseType("Type de la case active : " + game.getActiveCaseType());
		view.setActiveCaseCost("Coût de la case active : " + game.getActiveCaseCost() + " P");
	}

	private void moveActiveCase(Coordinates activeCase) {
		view.setActiveCase(activeCase.getRow(), activeCase.getCol());
	}

	private void displayMap(CaseMap map) {
		view.clearTiles();

		for (Coordinates coordinates : map) {
			var caseType = map.getCaseTypeAt(coordinates);
			var tileType = mapToTileType(caseType);
			view.setTileAt(tileType, coordinates.getRow(), coordinates.getCol());
		}
	}

	/**
	 * Renvoie le TileType correspondant au CaseType de la Case
	 * 
	 * @param caseType le CaseType de la Case
	 * @return le TileType correspondant au CaseType.
	 */
	public TileType mapToTileType(CaseType caseType) {
		switch (caseType) {
		case WATER:
			return TileType.WATER;
		case SAND:
			return TileType.SAND;
		case GRASSLAND:
			return TileType.GRASSLAND;
		case FOREST:
			return TileType.FOREST;
		case ROCK:
			return TileType.ROCK;
		default:
			return TileType.UNKNOWN;
		}
	}

	/**
	 * Déplace la case active de {@code deltaRow} lignes et de {@code deltaRow}
	 * colonnes.
	 *
	 */
	public void onMove(int deltaRow, int deltaCol) {
		game.move(deltaRow, deltaCol);
		moveActiveCase(game.getActiveCase());
		view.setLooterCase(game.getActiveCase().getRow() - 1, game.getActiveCase().getCol());
		updateActiveCaseOverlay();
	}

	/**
	 * Tente de creuser la case active et met à jour l'affichage en conséquence. Ne
	 * fais rien si la case active a déjà été creusee ou si elle est de type Eau.
	 *
	 */
	/*
	 * Post-conditions du creusage ===========================
	 * 
	 * Un creusage peut mener à 4 résultats différents :
	 * 
	 * - Si la case n'est pas creusable ou a été déjà creusé, la carte n'est pas
	 * modifié ni la bourse du joueur - Si la case ne donne rien, la case
	 * correspondante est marquée comme creusée et le joueur a dépensé C pièces où C
	 * correspond au cout de creusage de la case - Si la case donne un indice, la
	 * case correspondante est marquée comme creusée et le joueur a dépensé C pièces
	 * où C correspond au cout de creusage de la case - Si la case contenait un
	 * trésor de T pièces, la case correspondante est marquée comme creusée et le
	 * joueur a dépensé C pièces où C correspond au cout de creusage de la case et à
	 * reçu T pièces
	 */
	public void onDig() {
		DigResult result = game.dig();
		if (DigResult.UNDIGGABLE == result) {
			return;
		} else if (DigResult.NOTHING == result) {
			view.setSpriteAt(SpriteType.DUG, game.getActiveCase().getRow(), game.getActiveCase().getCol());
		} else if (DigResult.TREASURE_FOUND == result) {
			view.setSpriteAt(SpriteType.TREASURE, game.getActiveCase().getRow(), game.getActiveCase().getCol());
		} else {
			view.setSpriteAt(asSprite(game.getActiveCaseClue()), game.getActiveCase().getRow(),
					game.getActiveCase().getCol());
		}

		updateOverlay();
		onGameOver();
	}

	private void onGameOver() {
		if (game.isOver()) {
			game.setEndTime(System.currentTimeMillis());
			view.goTo(ViewNames.GAME_OVER);
		}
	}

	private SpriteType asSprite(Orientation clue) {
		return orient2Sprite.getOrDefault(clue, SpriteType.NONE);
	}

	/**
	 * Méthode appelée par la vue quand l'utilisateur souhaite interrompre la
	 * partie.
	 * 
	 * Ce superviseur demande à sa vue de naviguer vers le menu principal.
	 */

	public void onStop() {
		view.goTo(ViewNames.MAIN_MENU);
	}

}
