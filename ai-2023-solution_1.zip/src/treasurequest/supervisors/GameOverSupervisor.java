package treasurequest.supervisors;

import java.time.Duration;
import java.util.*;

import treasurequest.domains.*;
import treasurequest.supervisors.views.*;

/**
 * Réagit aux événements de haut-niveau de sa vue et lui fournit des données à
 * afficher.
 */
/*
 * = Conditions de fin de partie
 * 
 * - Tous les trésors ont été découverts
 * 
 * - Il ne reste plus de cases creusables par le joueur, car ce dernier n'a plus
 * assez de pièces
 */
/*
 * = CTT de la plus grande zone de cases creusées
 * 
 * @see treasurequest.domains.Player.getLargestZone()
 */
/*
 * = Choix de la collection pour mémoriser le nombre de fois qu'un profil est
 * atteint
 * 
 * TODO écrire vos arguments et votre choix
 * 
 * = Choix de l'implémentation pour mémoriser le nombre de fois qu'un profil est
 * atteint
 * 
 * TODO écrire vos arguments et votre choix
 */
public class GameOverSupervisor {

	private final PlayerProvider playerProvider;

	private GameOverView view;

	private Player lastPlayer;

	/**
	 * Construit un superviseur de fin de partie à l'aide d'un fournisseur de
	 * joueur.
	 */
	public GameOverSupervisor(PlayerProvider playerProvider) {
		this.playerProvider = Objects.requireNonNull(playerProvider);
	}

	public void setView(GameOverView view) {
		if (view == null) {
			return;
		}
		this.view = view;
	}

	/**
	 * Méthode appelée par la vue quand une navigation vers elle est en cours.
	 * 
	 * @param fromView la vue d'origine.
	 */
	public void onEnter(String fromView) {
		lastPlayer = playerProvider.getPlayer();

		this.view.clearPanels();

		addGameTimePanel(lastPlayer.getGameTime());
		addSpentAndReceivedPanels();
		addProfilePanel(lastPlayer.getLargestZone());
	}

	private void addSpentAndReceivedPanels() {
		this.view.addPanel(ResultType.LOSS, String.format("Vous avez dépensé %d P", lastPlayer.getSpentCoins()));
		this.view.addPanel(ResultType.GAIN, String.format("Vous avez gagné %d P", lastPlayer.getReceivedCoins()));
	}

	private void addGameTimePanel(Duration gameTime) {
		this.view.addPanel(ResultType.DURATION,
				String.format("Temps de jeu : %02d:%02d", gameTime.toMinutes(), gameTime.toSecondsPart()));
	}

	private void addProfilePanel(Zone zone) {
		ResultType profile = getProfile(zone);

		this.view.addPanel(profile, "Votre profil est celui d'un :" + profile);
	}

	private ResultType getProfile(Zone zone) {
		switch (zone.getType()) {
		case SAND:
			return ResultType.TOURIST;
		case GRASSLAND:
			return ResultType.FARMER;
		case FOREST:
			return ResultType.LUMBERJACK;
		case ROCK:
			return ResultType.MINER;
		default:
			return ResultType.NONE;
		}
	}

	/**
	 * Méthode appelée par la vue quand l'utilisateur souhaite retourner au menu
	 * principal.
	 */
	public void onGoToMain() {
		view.goTo(ViewNames.MAIN_MENU);
	}
}
