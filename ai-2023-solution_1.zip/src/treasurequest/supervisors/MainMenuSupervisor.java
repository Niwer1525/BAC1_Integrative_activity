package treasurequest.supervisors;

import java.util.*;

import treasurequest.domains.*;
import treasurequest.supervisors.views.*;


/**
 * Fournit les données qu'une vue représentant le menu principal doit afficher.
 * Réagit aux événements de haut niveau signalés par sa vue.
 * */
public class MainMenuSupervisor {
	private static final int NEW_GAME_ITEM = 0;
	private static final int RANDOM_GAME_ITEM = 1;
	private static final int EXIT_ITEM = 2;
	
	private static final String DEFAULT_MAP = "resources/maps/map-sample.txt";
	private static final String BIG_MAP = "resources/maps/big-map.txt";
	
	private final GameFactory gameFactory;
	private final CaseMapFactory mapFactory;
	
	private MainMenuView view;

	/**
	 * Construit une nouvelle instance de superviseur de menu principal à l'aide d'une fabrique de jeu.
	 * */
	public MainMenuSupervisor(GameFactory gameFactory, CaseMapFactory mapFactory) {
		this.gameFactory = Objects.requireNonNull(gameFactory);
		this.mapFactory = Objects.requireNonNull(mapFactory);
	}
	
	/**
	 * Définit la vue du superviseur.
	 * 
	 * En réaction, le superviseur communique à sa vue les items à afficer.
	 * */
	public void setView(MainMenuView view) {		
		this.view = Objects.requireNonNull(view);;
		this.view.setItems(List.of(
				"Nouvelle Partie",
				"Partie Aléatoire",
				"Quitter"));
	}

	/**
	 * Méthode appelée par la vue quand l'utilisateur sélectionne un item.
	 * 
	 * @param itemPos la position de l'item sélectionné. {@code item in [0; items.length[}
	 * */
	public void onItemSelected(int itemPos) {
		if(EXIT_ITEM == itemPos) {
			view.confirmExit();
		} else if (itemPos == NEW_GAME_ITEM) {
			gameFactory.newGame(mapFactory.load(DEFAULT_MAP));
			view.goTo(ViewNames.PLAY_GAME);
		} else if (itemPos == RANDOM_GAME_ITEM) {
			gameFactory.newGame(mapFactory.load(BIG_MAP, 16));
			view.goTo(ViewNames.PLAY_GAME);
		}
	}
}
