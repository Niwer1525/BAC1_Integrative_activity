package treasurequest.supervisors.views;

/**
 * Enumère les types de résultat disponibles.
 * */
public enum ResultType {
	GAIN("Gains du joueur"), 
	LOSS("Pertes"), 
	DURATION("Bilan"), 
	LUMBERJACK("Bucheron"), 
	MINER("Mineur"), 
	FARMER("Fermier"), 
	TOURIST("Touriste"), 
	LOOTER("Gains du pilleur"),
	NONE("Inconnu"), 
	EFFICIENCY("Efficacite");

	private String title;

	ResultType(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}
}
