package treasurequest.swing.components;

import java.awt.Color;
import java.awt.Graphics2D;

import treasurequest.swing.Theme;
import treasurequest.swing.engine.GameComponent;
import treasurequest.swing.engine.Vector2f;

/**
 * Met en évidence un élément sélectionné à l'aide d'un rectangle.
 * 
 * @author Nicolas Hendrikx
 */
public class ItemSelector extends GameComponent {

	private Color fillColor;
	private boolean visible;
	
	/**
	 * {@inheritDoc}
	 * */
	public ItemSelector(int left, int top, int weight, int height) {
		this(left, top, weight, height, Theme.SECONDARY_COLORA);
		this.visible = false;
	}
	
	public ItemSelector(int left, int top, int weight, int height, Color fillColor) {
		super(left, top, weight, height);
		this.setFillColor(fillColor);
	}

	public ItemSelector(int left, int top, int weight, int height, boolean b) {
		this(left, top, weight, height, Theme.SECONDARY_COLORA);
		this.visible = true;
	}

	private Color getFillColor() {
		return fillColor;
	}

	private void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public void moveTo(Vector2f newPos, float factor) {
		this.visible = true;
		super.moveTo(newPos, factor);
	}
	
	/**
	 * {@inheritDoc}
	 * */
	@Override
	public void repaint(Graphics2D painter) {
		if(!visible) {
			return;
		}
		
		painter.setColor(getFillColor());
		painter.fillRoundRect(getLeft(), getTop(), getWidth(), getHeight(), 5, 5);
		
		painter.setColor(getFillColor().brighter());
		painter.drawRoundRect(getLeft(), getTop(), getWidth(), getHeight(), 5, 5);
	}

}
