package treasurequest;

import javax.swing.SwingUtilities;

import treasurequest.domains.*;
import treasurequest.supervisors.*;
import treasurequest.supervisors.views.ViewNames;
import treasurequest.swing.*;

/**
 * Construit l'application et affiche la fenêtre principale.
 * 
 * @author Nicolas Hendrikx
 *
 */
public class Program {

	/**
	 * Point d'entrée de l'application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(Program::buildAndRun);

	}
	
	private static void buildAndRun() {				 
		var gameFactory = new TreasureQuestGameFactory(
				new RandomGenerator(), 
				new RandomCoordinatesSequence(), 
				new DistanceValueClueSetter());		
		var mapFactory = new TxtFileCaseMapFactory(new RandomGenerator());
		
		var menuSupervisor = new MainMenuSupervisor(gameFactory, mapFactory);
		var playSupervisor = new PlayGameSupervisor(gameFactory);
		var endSupervisor = new GameOverSupervisor(gameFactory);

		MainWindow main = new MainWindow("B1UE09 - Treasure Quest", 
				new MainMenuSwingView(menuSupervisor),
				new PlayGameSwingView(playSupervisor), 
				new GameOverSwingView(endSupervisor));

		main.start(ViewNames.MAIN_MENU);
	}

}
