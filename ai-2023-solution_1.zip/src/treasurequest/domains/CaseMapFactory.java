package treasurequest.domains;

/**
 * Spécifie les méthodes de création de cartes à partir d'un chemin de fichier.
 * 
 * Deux méthodes sont actuellement disponibles :
 * <ul>
 * <li>Par lecture du fichier
 * <li>Par lecture de fichier, puis extraction d'une zone
 * </ul>
 * */
public interface CaseMapFactory {

	/**
	 * Charge une carte depuis un fichier.
	 * 
	 * Retourne {@code CaseMap.SINGLE} si le chemin vers le fichier est null ou si
	 * la carte lue n'est pas jouable.
	 * 
	 * @param filePath le chemin vers le fichier
	 */
	CaseMap load(String filePath);

	/**
	 * Charge une carte depuis un fichier par extraction d'une sous-zone de {@code fragmentSize}.
	 * 
	 * Retourne {@code CaseMap.SINGLE} si le chemin vers le fichier est null ou si
	 * la carte lue n'est pas jouable.
	 * 
	 * @param filePath le chemin vers le fichier
	 * @param fragmentSize un entier positif indiquant la taille de la zone à extraire
	 */
	CaseMap load(String filePath, int fragmentSize);

}