package treasurequest.domains;

/**
 * Décrit comment créer des parties à partir d'une carte.
 */
public interface GameFactory {
	/**
	 * 
	 * Crée une nouvelle partie à partir d'une carte.
	 * 
	 * @param map une carte, a priori vide. 
	 */
	void newGame(CaseMap map);
}