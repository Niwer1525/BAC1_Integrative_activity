package treasurequest.domains;

/**
 * Spécifie comment obtenir le joueur.
 * */
public interface PlayerProvider {
	/**
	 * Retourne le joueur.
	 * */
	Player getPlayer();
}
