package treasurequest.domains;

import java.util.*;

/**
 * Décrit comment obtenir une zone à partir .
 * */
public interface ZoneExploration {
	/**
	 * Retourne une zone obtenue à partir des paires {@code <coordonnée, type de case>}.
	 * */
	Zone computeFrom(Set<Map.Entry<Coordinates, CaseType>> cases);
}
