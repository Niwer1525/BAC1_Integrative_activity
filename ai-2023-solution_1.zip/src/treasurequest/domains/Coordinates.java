package treasurequest.domains;

import java.util.Objects;

/**
 * Représente les coordonnées d'une case en terme de numéros de ligne et de colonnes. 
 * Les objets de cette classe sont immuables.
 */
public final class Coordinates implements Comparable<Coordinates> {
	/**
	 * Représente la coordonnée (0; 0)
	 */
	public static final Coordinates ORIGIN = ofRowAndCol(0, 0);

	private final int row;
	private final int col;

	/**
	 * Crée un objet Coordinates avec un numéro de ligne et de colonne spécifié.
	 * 
	 */
	public static Coordinates ofRowAndCol(int row, int col) {
		return new Coordinates(row, col);
	}

	private Coordinates(int row, int col) {
		this.row = row;
		this.col = col;
	}

	/**
	 * Retourne le numéro de la ligne.
	 */
	public int getRow() {
		return row;
	}

	/**
	 * Retourne le numéro de la colonne.
	 */
	public int getCol() {
		return col;
	}

	/**
	 * Retourne une nouvelle coordonnée correspondant à
	 * {@code (this.row + dRow; this.col + dCol)}.
	 */
	public Coordinates plus(int dRow, int dCol) {
		return new Coordinates(row + dRow, col + dCol);
	}

	/**
	 * Calcule la distance euclidienne entre cette coordoonées et la coordonnée cible.
	 * 
	 * @param target la coordonnée cible. Si cette dernière vaut null, la méthode retourne {@code Double.NaN}.
	 */
	public double getDistanceTo(Coordinates target) {
		if(target == null) {
			return Double.NaN;
		}
		
		int deltaRow = this.getRow() - target.getRow();
		int deltaCol = this.getCol() - target.getCol();

		return Math.sqrt(deltaRow * deltaRow + deltaCol * deltaCol);
	}

	/**
	 * Retourne l'orientation de cette coordonnée par rapport à une coordonnée cible.
	 * <p>
	 * Cette méthode n'est pas symétrique. Si c1 et c2 sont deux coordonnées différentes, 
	 * c1.getOrientationTo(c2) != c2.getOrientationTo(c1).
	 * </p>
	 * */
	public Orientation getOrientationTo(Coordinates target) {
		int dRow = target.getRow() - this.getRow();
		int dCol = target.getCol() - this.getCol();
		
		if (dRow < 0) {
			return getNorthClue(dCol);
		} else if (dRow == 0) {
			return getEastWestClue(dCol);
		} else {
			return getSouthClue(dCol);
		}
	}

	private static Orientation getNorthClue(int deltaCol) {
		if (deltaCol < 0) {
			return Orientation.NORTH_WEST;
		} else if (deltaCol == 0) {
			return Orientation.NORTH;
		} else {
			return Orientation.NORTH_EAST;
		}
	}
 
	private Orientation getEastWestClue(int deltaCol) {
		if (deltaCol > 0) {
			return Orientation.EAST;
		} else if (deltaCol < 0) {
			return Orientation.WEST;
		} else {
			return Orientation.NONE;
		}
	}

	private Orientation getSouthClue(int deltaCol) {
		if (deltaCol > 0) {
			return Orientation.SOUTH_EAST;
		} else if (deltaCol == 0) {
			return Orientation.SOUTH;
		} else {
			return Orientation.SOUTH_WEST;
		}
	}
	
	@Override
	public String toString() {
		return String.format("Coordinates(%d, %d)", row, col);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return Objects.hash(col, row);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		
		if (!(obj instanceof Coordinates))
			return false;
		Coordinates other = (Coordinates) obj;
		return col == other.col && row == other.row;
	}

	/**
	 * Compare deux coordonnées en se basant sur leurs distances par rapport à l'origine.
	 * <p>Retourne -1.0 si la distance de cette coordonnée est plus petite que celle de l'autre,
	 * 0 si les distances sont égales et 1.0 si cette distance est plus grande que celle de l'autre.
	 * </p> 
	 * */
	@Override
	public int compareTo(Coordinates other) {
		double distComparison = this.getDistanceTo(ORIGIN) - other.getDistanceTo(ORIGIN);
		if(Double.compare(distComparison, 0.0) != 0) {
			return (int)Math.signum(distComparison);
		} else {
			double thisAngle = Math.asin(this.row/this.getDistanceTo(ORIGIN));
			double otherAngle = Math.asin(other.row/other.getDistanceTo(ORIGIN));
			double angleComparison = thisAngle - otherAngle;
			
			return (int)Math.signum(angleComparison);
		}
	}

}
