package treasurequest.domains;

import java.util.*;

/**
 * Associe un ensemble de coordonnées à des cases.
 * 
 * <p>
 * Cette classe masque le concept de case en proposant plusieurs accesseurs
 * basée sur des Coordonnées. Elle est itérable sur ces coordonnées.
 * </p>
 */
/*
 * = Choix de la collection
 * 
 * Nous souhaitons obtenir une case sur base de la coordonnées associé. Nous ne
 * souhaitons pas maintenir d'ordre entre les coordonnées. Pour une case, il
 * n'existe qu'une coordonnées.
 * 
 * Ces besoins nous font opter pour une Map<Coordinates, Case>
 * 
 * = Choix de l'implémentation
 * 
 * Nous avons le choix entre une HashMap, LinkedHashMap voire une TreeMap. Nous
 * pouvons exclure cette dernière, car nous ne souhaitons pas maintenir d'ordre
 * parmi les éléments. Les CTT des collections restantes sont en O(1) pour la
 * plupart des opérations. Cependant, la HashMap donne de meilleures
 * performances, car elle ne maintient pas de liste chainées.
 * 
 * En conclusion, nous optons pour une HashMap.
 */
/*
 * = CTT du placement des trésors adapté
 * 
 * TODO écrire votre raisonnement et votre conclusion pour la CTT
 * */
public class CaseMap implements Iterable<Coordinates> {
	private final Map<Coordinates, Case> coordsToCases;

	/**
	 * Fabrique une carte à partir de paires {@code <Coordinates, Case>}.
	 * 
	 * @param cases les paires {@code <Coordinates, Case>} qui composent cette
	 *              carte. Si l'ensemble des paires vaut null ou est vide, un carte
	 *              single est retournée.
	 */
	public static CaseMap ofPairs(Map<Coordinates, Case> cases) {
		if (cases == null || cases.isEmpty()) {
			return single();
		} else {
			return new CaseMap(cases);
		}
	}

	/**
	 * Retourne une nouvelle carte composée d'une seule case de type sable.
	 */
	public static CaseMap single() {
		return new CaseMap(Map.of(Coordinates.ORIGIN, Case.ofType(CaseType.SAND)));
	}

	private CaseMap(Map<Coordinates, Case> cases) {
		this.coordsToCases = new HashMap<>(cases);
	}

	/**
	 * Retourne les coordonnées d'une case proche du centre de la carte.
	 */
	public Coordinates getCenter() {
		Coordinates max = Coordinates.ofRowAndCol(Integer.MIN_VALUE, Integer.MIN_VALUE);
		Coordinates min = Coordinates.ofRowAndCol(Integer.MAX_VALUE, Integer.MAX_VALUE);

		for (Coordinates coordinates : this) {
			if (max.compareTo(coordinates) < 0) {
				max = coordinates;
			}

			if (min.compareTo(coordinates) > 0) {
				min = coordinates;
			}
		}

		var rows = (max.getRow() - min.getRow()) / 2;
		var cols = (max.getCol() - min.getCol()) / 2;

		return min.plus(rows, cols);
	}

	/**
	 * Retourne le cout de la case de coordonnées {@code coord}.
	 */
	public CaseType getCaseTypeAt(Coordinates coordinates) {
		return getCaseAt(coordinates).getCaseType();
	}

	/**
	 * Retourne le cout de la case de coordonnées {@code coord}.
	 */
	public int getCaseCostAt(Coordinates coordinates) {
		return getCaseAt(coordinates).getDigCost();
	}

	/**
	 * Retourne les pièces de la case de coordonnées {@code coord}.
	 */
	public Orientation getClueAt(Coordinates coordinates) {
		return getCaseAt(coordinates).getClue();
	}

	/**
	 * Retourne le montant du trésor contenu dans la case
	 * 
	 * @param coordinates les coordonnées de la case
	 * @return le montant du trésor
	 */
	public int getTreasureAt(Coordinates coordinates) {
		return getCaseAt(coordinates).getAmount();
	}

	private Case getCaseAt(Coordinates coordinates) {
		if (coordsToCases.containsKey(coordinates)) {
			return coordsToCases.get(coordinates);
		} else {
			return Case.UNKOWN;
		}
	}

	/**
	 * Retourne les cases creusables (CTT en O(C) où C correspond au nombre de cases
	 * de la carte).
	 */
	public Collection<Coordinates> getDiggableCoords() {
		Collection<Coordinates> diggableCoords = new HashSet<>(coordsToCases.size(), 1.0f);

		for (Coordinates coord : coordsToCases.keySet()) {
			var caseObj = coordsToCases.get(coord);
			if (caseObj.isDiggable()) {
				diggableCoords.add(coord);
			}
		}

		return diggableCoords;
	}

	/**
	 * Retourne les coordonnées des trésors situés autour de {@code coord}.
	 */
	/*
	 * = Choix du type de collection pour les cases environnantes
	 * 
	 * Nous devons mémoriser des coordonnées en vue des parcourir séquentiellement.
	 * 
	 * Nous ne devons pas faire d'accès sélectif, en outre l'ordre du parcourt n'a
	 * pas d'importance. Enfin, nous ne souhaitons pas de doublons.
	 * 
	 * En conclusion, nous optons pour un Set.
	 * 
	 * = Choix de l'implémentation
	 * 
	 * Deux opérations seront utilisées : l'ajout d'un élément et le parcourt
	 * séquentiel à l'aide d'un itérateur. Sur base du tableau ci-dessous, nous
	 * pouvons éliminer rapidement la TreeSet.
	 * 
	 *                | add(T) | parcours  |
	 *                |--------|-----------|
	 *  HashSet       | O(1)   | O(N) 
	 *  LinkedHashSet | O(1)   | O(N)
	 *  TreeSet       | O(Lg N)| O(N)
	 * 
	 * Pour les deux candidates restants, la HashSet offre de meilleures
	 * performances, car elle ne doit pas mémoriser l'ordre d'insertion des
	 * éléments.
	 * 
	 * En conclusion, nous optons pour la HashSet.
	 */
	public Set<Coordinates> getTreasuresAround(Coordinates coord) {
		Set<Coordinates> result = new HashSet<>();
		for (int dRow = -2; dRow <= 2; dRow++) {
			for (int dCol = -2; dCol <= 2; dCol++) {
				Coordinates neighbor = coord.plus(dRow, dCol);
				if (!neighbor.equals(coord) && getTreasureAt(neighbor) != 0) {
					result.add(neighbor);
				}
			}
		}
		return result;
	}

	/**
	 * Compte le nombre de cases creusables pour {@code coins} pièces.
	 */
	public int countDiggableCaseFor(int coins) {
		int count = 0;

		for (Coordinates candidates : this) {
			var caseObj = coordsToCases.get(candidates);

			if (caseObj.isDiggableFor(coins)) {
				++count;
			}
		}
		return count;
	}

	/**
	 * Retourne {@code true} si la case {@code coordinate} est creusable et pas
	 * encore creusée.
	 */
	public boolean isDiggableFor(int availableCoins, Coordinates coordinate) {
		Case caseObj = getCaseAt(coordinate);
		return caseObj.isDiggableFor(availableCoins);
	}

	/**
	 * Retourne {@code true} si la case aux coordonnées données est creusable et
	 * sans trésor.
	 */
	public boolean isDiggableAndEmpty(Coordinates coord) {
		Case caseObj = getCaseAt(coord);
		return caseObj.isDiggable() && caseObj.getAmount() == 0;
	}

	/**
	 * Retourne le nombre de trésors restants sur cette carte.
	 */
	public int countTreasureLeft() {
		int count = 0;

		for (var candidates : this) {
			var caseObj = coordsToCases.get(candidates);

			if (caseObj.canBeDug() && caseObj.getAmount() > 0) {
				++count;
			}
		}

		return count;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * Cette implémentation retourne une copie des coordonnées.
	 */
	@Override
	public Iterator<Coordinates> iterator() {
		return Set.copyOf(coordsToCases.keySet()).iterator();
	}

	/**
	 * Définit la case comme étant creusée.
	 */
	public void digAt(Coordinates coordinate) {
		Case caseObj = getCaseAt(coordinate);
		caseObj.setDug();
	}

	/**
	 * Définit le montant de la case de coordonnée {@code coord}. Ne fait rien si la
	 * coordonées n'existe pas ou si la case n'est pas creusable.
	 */
	protected void setAmountAt(int amount, Coordinates key) {
		var caseObj = getCaseAt(key);
		caseObj.setAmount(amount);
	}

	/**
	 * Définit l'indice de la case de coordonnée {@code coord}. Ne fait rien si la
	 * coordonées n'existe pas ou si la case n'est pas creusable.
	 */
	protected void setClueAt(Orientation clue, Coordinates coord) {
		var caseObj = getCaseAt(coord);
		caseObj.setClue(clue);
	}

}
