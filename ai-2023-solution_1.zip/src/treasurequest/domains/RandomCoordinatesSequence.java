package treasurequest.domains;

import java.util.*;

/**
 * Génère une permutation d'une liste de coordonnées et retourne ses éléments.
 * */
public class RandomCoordinatesSequence implements CoordinatesSequence {

	private List<Coordinates> sources;
	private int pos;
	
	/**
	 * {@inheritDoc}
	 * <p>
	 * Une copie de la collection est créée puis mélangée.
	 * </p>
	 * */
	@Override
	public void setSelectableCoords(Collection<Coordinates> coordinates) {
		sources = new ArrayList<>(coordinates);
		Collections.shuffle(sources);
		pos = 0;
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * La séquence étant infinie, elle recommence au début une fois la fin des coordonnées d'origine atteinte.
	 * </p>
	 * */
	@Override
	public Coordinates next() {
		Coordinates next = sources.get(pos);
		pos = (pos + 1) % sources.size();
		
		return next;
	}

}
