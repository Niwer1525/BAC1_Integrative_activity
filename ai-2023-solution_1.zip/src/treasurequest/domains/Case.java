package treasurequest.domains;

import java.util.Objects;

/**
 * Représente une case de la carte. 
 * <p>
 * Chaque case possède un type, un montant, une orientation et un indicateur de creusage.
 * </p>
 * <p>
 * Pour toute case, les invariants suivants sont à respecter :
 * <ul>
 * </li>{@code (this.montant > 0 => this.clue == None) && (this.clue != None => this.montant == 0)}
 * </li>{@code this.caseType == WATER => this.isDug == false && this.montant == 0 && this.clue == NONE}
 * </ul>
 * </p>
 */
final class Case {

	/**
	 * Représente une case inconnue de type Unknown.
	 * */
	public static final Case UNKOWN = ofType(CaseType.UNKNOWN);

	private final CaseType caseType;
	private int amount;
	private Orientation clue = Orientation.NONE; 
	private boolean isDug;

	/**
	 * Construit une case de type {@code caseType} sans montant ni indice et non-creusée.
	 * 
	 * @throws NullPointerException si l'argument vaut null
	 */	
	public static Case ofType(CaseType caseType) {		
		return new Case(Objects.requireNonNull(caseType));
	}
	
	private Case(CaseType caseType) {
		this.caseType = caseType;
		this.amount = 0;
		this.isDug = false;
	}

	/**
	 * Retourne le type de la case.
	 */
	public CaseType getCaseType() {
		return caseType;
	}
	
	/**
	 * Retourne le montant du trésor contenu dans cette case.
	 */
	public int getAmount() {
		return this.amount;
	}

	/**
	 * Retourne le coût pour creuser cette case.
	 */
	public int getDigCost() {
		return caseType.getCost();
	}
	
	/**
	 * Retourne l'indice de cette case
	 */
	public Orientation getClue() {
		return this.clue;
	}
	
	/**
	 * Vérifie si la case est creusable sans tenir compte du fait qu'elle ait été déjà creusée.
	 * 
	 * @return {@code true} ssi {@code this.caseType in (Water, Unknown)}
	 */
	public boolean isDiggable() {
		return this.getCaseType() != CaseType.WATER && this.getCaseType() != CaseType.UNKNOWN;
	}
	
	/**
	 * Retourne {@code true} si la case est creusable mais pas encore creusée.
	 * */
	public boolean canBeDug() {
		return isDiggable() && !this.isDug;
	}
	
	/**
	 * Retourne {@code true} si la case peut être creusé pour {@code availableCoins}.
	 * */
	public boolean isDiggableFor(int availableCoins) {
		return canBeDug() && this.getDigCost() <= availableCoins;
	}
	
	/**
	 * Définit le montant du trésors contenu dans la case (uniquement si celle-ci est creusable).
	 * 
	 * @param amount la quantité de pièces contenues par la case. Si cette valeur est négative, elle est remplacée par 0.
	 */
	public void setAmount(int amount) {
		int sanitizedAmount = Math.max(0, amount);
	    if (isDiggable() && Orientation.NONE == this.clue) {
	        this.amount = sanitizedAmount;
	    } else {
	        this.amount = 0;
	    }
	}
	
	/**
	 * Définit l'indice contenu dans cette case.
	 * 
	 * @param clue la valeur de l'indice. Si cette valeur vaut null, elle est remplacée par None.
	 */
	public void setClue(Orientation clue) {
		if(isDiggable() && amount == 0) {
			this.clue = Objects.requireNonNullElse(clue, Orientation.NONE);
		}
	}
	
	/**
	 * Creuse la case si elle est creusable, ne fait rien sinon.
	 */
	public void setDug() {
		if(isDiggable()) {
			this.isDug = true;
		}
	}
	
}
