package treasurequest.domains;

import java.util.*;

/**
 * Une zone est une collection de cases de coordonnées adjacentes de même type.
 * */
public class Zone {

	public static final Zone EMPTY = new Zone(null, CaseType.UNKNOWN);
	private final CaseType type;
	private final Set<Coordinates> coords = new HashSet<>();
	
	/**
	 * Construit une zone dont la première coordonnée est coord et dont les cases sont de type {@code value}.
	 * */
	public Zone(Coordinates coord, CaseType type) {
		if(coord != null) {
			coords.add(coord);
		}
		this.type = Objects.requireNonNull(type);
	}

	/**
	 * Retourne le type de cette zone.
	 * */
	public CaseType getType() {
		return type;
	}

	/**
	 * Retourne le nombre de cases qui composent cette zone.
	 * */
	public int getSize() {
		return coords.size();
	}
	
	/**
	 * Retourne la zone de plus grande taille entre cette zone et l'autre zone.
	 * 
	 * <p>En cas d'égalité, la zone qui reçoit l'appel est retournée.</p>
	 * 
	 * @param other {@code other==null}, il est remplacé par la zone vide.
	 * 
	 * */
	public Zone largestBetween(Zone other) {
		Zone sanitizedOther = Objects.requireNonNullElse(other, Zone.EMPTY);
		
		return this.getSize() >= sanitizedOther.getSize() ? this : sanitizedOther;
	}

	/**
	 * Retourne {@code true} si le type de cette zone est égal à {@code caseType}.
	 * */
	public boolean hasSameType(CaseType caseType) {
		return this.type == caseType;
	}

	/**
	 * Ajoute {@newCoord} si cette dernière ne fait pas déjà partie de cette zone.
	 * 
	 * @throws NullPointerException si {@code newCoord == null}.
	 * */
	public void add(Coordinates newCoord) {
		coords.add(Objects.requireNonNull(newCoord));
		
	}

}
