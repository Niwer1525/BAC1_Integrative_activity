package treasurequest.domains;

/**
 * Enumère les résultats possible pour un creusage.
 * */
public enum DigResult {
	UNDIGGABLE, NOTHING, TREASURE_FOUND, CLUE_FOUND
}
