package treasurequest.domains;

import java.util.*;

/**
 * Crée une nouvelle partie et mémorise la dernière partie créé.
 * <p>
 * La création d'une partie se fait à partir d'une carte à fournir. Cette carte est utilisée
 * pour déterminer la mise de départ du joueur, placer les trésors et générer les indices.
 * </p>
 */
/*
 * = CTT du placement des trésors
 * 
 * L'algorithme de remplissage d'une carte avec des trésors correspond à la méthode {@code filleWithTreasures}.
 * 
 * Sa première étape consiste à récupérer la liste des coordonnées des cases creusables. 
 * La méthodes correspondante construit une nouvelle liste en inspectant toutes les cases de la cartes. 
 * Sa CTT est linéaire en fonction du nombre de cases de la carte que nous appellerons C => C
 * 
 * La seconde étape consiste à sélectionner T cases pour y placer T trésors avec T = max(1, 10%C). Cette opération
 * mélange les éléments d'une copie de la liste des cases creusables avant d'extraire une sous-liste de T élément => C + C + T
 * 
 * Enfin, pour chaque trésor, nous générons un nombre de pièces aléatoire que nous affectons à la case correspondante.
 * Ces deux opérations sont de complexité constante => T x (1+1) => 2xT
 * 
 * En conclusion, cette algorithme compte environ 3x(C + T) opérations. Sa CTT est en O(C+T).
 */
public class TreasureQuestGameFactory
		implements GameFactory, GameProvider, PlayerProvider {

	private final IntSequence coinsGenerator;
	private final CoordinatesSequence placesGenerator;
	private final CluesSetter cluesSetter;
	
	private final Player player;
	
	private TreasureQuestGame lastGame;
	
	/**
	 * Construit une fabrique de jeu à partir de deux séquences.
	 * 
	 * @param coinsSeq séquence d'entiers utilisée pour générer le nombre de pièces des trésors.
	 * @param placesSeq séquences de coordonnées utilisée pour placer les trésors.
	 * */
	public TreasureQuestGameFactory(IntSequence coinsSeq, CoordinatesSequence placesSeq, CluesSetter clueSetter) {
		this.coinsGenerator = Objects.requireNonNull(coinsSeq);
		this.placesGenerator = Objects.requireNonNull(placesSeq);
		this.cluesSetter = Objects.requireNonNull(clueSetter);
		this.player = new Player(0, Coordinates.ORIGIN);
	}
	
	/**
	 * {@inheritDoc}
	 * 
	 * Retourne le dernier objet TreasureQuestGame contenant la partie en cours.
	 * 
	 * @throw {@link NullPointerException} si aucune partie n'a été créée.
	 */
	
	@Override
	public TreasureQuestGame getGame() {
		return Objects.requireNonNull(lastGame);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * Crée une nouvelle partie du jeu TreasureQuest en chargeant la carte,
	 * initialisant les trésors et créant le joueur avec sa bourse de départ, si il s'agit de la première partie.
	 */
	@Override	
	public void newGame(CaseMap caseMap) {
		fillWithTreasures(caseMap);
		fillWithClues(caseMap);
				
		this.lastGame = new TreasureQuestGame(player, caseMap);
	}
	
	private void fillWithTreasures(CaseMap caseMap) {
		List<Coordinates> diggableCoords = shuffleAndTake(caseMap.getDiggableCoords(), 10);
		
	    for (var coord : diggableCoords) {
	        int amount = coinsGenerator.nextBetween(10, 20);
	        caseMap.setAmountAt(amount, coord);
	    } 
	}

	private List<Coordinates> shuffleAndTake(Collection<Coordinates> diggableCoords, int percent) {
		final int count = Math.max(diggableCoords.size()/percent, 1);		
		List<Coordinates> selection = new ArrayList<>(count);
		
		placesGenerator.setSelectableCoords(diggableCoords);		
		for(int times= 0; times < count; ++times) {
			selection.add(placesGenerator.next());
		}
			
		return selection;
	}
	
	private void fillWithClues(CaseMap caseMap) {
		cluesSetter.setClues(caseMap);
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public Player getPlayer() {
		return player;
	}
	
}
