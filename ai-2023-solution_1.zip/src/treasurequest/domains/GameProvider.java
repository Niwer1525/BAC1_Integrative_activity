package treasurequest.domains;
/**
 * Décrit comment obtenir une partie.
 */
public interface GameProvider {
	/**
	 * Retourne une partie.
	 */
	TreasureQuestGame getGame();

	
}
