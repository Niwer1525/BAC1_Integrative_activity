package treasurequest.domains;

/**
 * Décrit comment demander le placement des indices sur une carte.
 * */
public interface CluesSetter {
	/**
	 * Place les indices sur {@code map}.
	 * 
	 * <p>On suppose que la map compte des trésors, sans quoi la méthode ne fait rien.<p>
	 * */
	void setClues(CaseMap map);
}
