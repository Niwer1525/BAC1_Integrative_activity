package treasurequest.domains;

/**
 * Représente une orientation possible.
 * 
 * Typiquement, l'orientation est calculée entre deux {@link treasurequest.domains.Coordinates}.
 *
 */
public enum Orientation {
	WEST, NORTH_WEST, NORTH, NORTH_EAST, EAST, SOUTH_EAST, SOUTH, SOUTH_WEST, NONE;
}
