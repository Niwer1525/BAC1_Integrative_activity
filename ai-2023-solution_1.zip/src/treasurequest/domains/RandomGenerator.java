package treasurequest.domains;

import java.util.Random;
/**
 * Représente une séquence pseudo-aléatoire d'entiers.
 */
public class RandomGenerator implements IntSequence {
	
		private final Random random;
		/**
		 * Initialise un objet RandomGenerator
		 */
		public RandomGenerator() {
			random = new Random();
		}
		/**
		 * Génere un nombre aléatoire entre @min et @max compris
		 */
		@Override
		public int nextBetween(int min, int max) {
		    return min + random.nextInt(max - min + 1);
		} 	
		
}
