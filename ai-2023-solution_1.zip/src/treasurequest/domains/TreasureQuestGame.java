package treasurequest.domains;

import java.time.Duration;
import java.util.*;

/**
 * Cette classe contrôle l'état du joueur et de la carte et plus généralement de la partie.
 * Elle est notamment capable de déterminer le résultat d'un creusage et de dire si une partie est finie.
 **/
/*
 * = CTT du calcul d’indices
 * 
 * @see treasurequest.domains.DistanceValueClueSetter
 * 
 * = Choix de collection et d'implémentation pour les case environnantes
 * 
 * @see treasurequest.domains.CaseMap#getTreasuresAround(Coordinates)
 * */
public class TreasureQuestGame {
	private final Player player;
	private final CaseMap caseMap;
	
	private long startedAt;

	/**
	 * Initialise un objet TreasureQuestGame.
	 *
	 * @param player  le joueur de la partie.
	 * @param caseMap la carte (grille) de jeu.
	 */
	public TreasureQuestGame(Player player, CaseMap caseMap) {		
		this.player = Objects.requireNonNull(player);
		this.caseMap = Objects.requireNonNull(caseMap);	
	}

	/**
	 * Retourne la carte de jeu.
	 */
	public CaseMap getCaseMap() {
		return caseMap;
	}
	

	/**
	 * Retourne les coordonnées de la case active.
	 */
	public Coordinates getActiveCase() {
		return player.getPosition();
	}

	/**
	 * Retourne le montant de la bourse du joueur (son nombre de coins).
	 */
	public int getPlayerCoins() {
		return player.getCoins();
	}

	/**
	 * Retourne le type de la case active.
	 *
	 * @param activeCaseCoordinates les coordonnées de la case active.
	 * @return le type de la case active (CaseType).
	 */
	public CaseType getActiveCaseType() {
		return caseMap.getCaseTypeAt(player.getPosition());
	}

	/**
	 * Retourne le coût pour creuser la case active.
	 *
	 * @param activeCaseCoordinates les coordonnées de la case active.
	 * @return le coût de creuser la case active.
	 */
	public int getActiveCaseCost() {
		return caseMap.getCaseCostAt(player.getPosition());
	}
	
	/**
	 * Retourne l'indice placé sous la case active.
	 * */
	public Orientation getActiveCaseClue() {
		return caseMap.getClueAt(player.getPosition());
	}
	
	private int getActiveCaseValue() {
		return caseMap.getTreasureAt(player.getPosition());
	}

	/**
	 * Retourne {@code true} si :
	 * <ul>
	 * <li>tous les trésors ont été trouvés
	 * <li>ou si il ne reste aucune case creusable par le joueur, étant donné sa bourse.
	 * </ul>
	 * */
	public boolean isOver() {
		return getTreasureCount() == 0 || caseMap.countDiggableCaseFor(player.getCoins()) == 0;
	}

	/**
	 * Retourne le nombre total de trésors sur la carte de jeu.
	 *
	 * @return le nombre total de trésors sur la carte.
	 */
	public int getTreasureCount() {
		return caseMap.countTreasureLeft();
	}

	/**
	 * Démmare la partie à {@code startedAt} et
	 * Donne au joueur 2 x le nombre de cases creusables en pièces.
	 * */
	public void start(long startedAt) {
		this.startedAt = startedAt;
		player.receiveCoins(2*caseMap.countTreasureLeft());
		player.reset(caseMap.getCenter());
	}
		
	/**
	 * Tente de déplacer ce joueur dans la direction (deltaRow;delateCol).
	 * */
	public void move(int deltaRow, int deltaCol) {
		player.move(deltaRow, deltaCol);
		if(caseMap.getCaseTypeAt(player.getPosition()) == CaseType.UNKNOWN) {
			player.move(-deltaRow, -deltaCol);
		}
	}
	
	/**
	 * Creuse la case active et retourne le résultat du creusage.
	 */
	public DigResult dig() {
		if(caseMap.isDiggableFor(player.getCoins(), player.getPosition())) {
			player.dig(caseMap);
			
			if(getActiveCaseValue() > 0) {
				return DigResult.TREASURE_FOUND;
			} else if(getActiveCaseClue() != Orientation.NONE) {
				return DigResult.CLUE_FOUND;
			} else {
				return DigResult.NOTHING;
			}
		} else {
			return DigResult.UNDIGGABLE;
		}
	}


	/**
	 * Ajoute du temps de jeu à la partie
	 */
	public void setEndTime(long time) {
		this.player.addGameTime(Duration.ofMillis(time - this.startedAt));
	}

}
