package treasurequest.domains;

import java.util.Set;

/**
 * Place des indices sur la cartes en fonction de différentes mesure de
 * distances.
 */
/*
 * = CTT du calcul des indices
 * 
 * La méthode setClues parcourt les coordonnées de la carte (C répétitions).
 * 
 * Pour chaque case creusable, on récupère la liste des trésors proches. Cette méthode
 * construit une liste d'au plus VxV trésors où V correspondant au nombre de cases formant 
 * un coté de la zone de recherche. Les trésors sont ensuite inspectés pour déterminer celui vers lequel l'indice 
 * pointera (VxV répétitions).
 * 
 * L'algorithme de comparaison a un temps constant car il ne compte ni boucle, ni opérations sur les collections.
 * 
 * En conclusion, la CTT de cette algorithme est en O(CxV²) dans le pire des case
 * où C est le nombre de cases et V est le nombre de case formant un côté de la zone de recherche.
 * Cependant, à cause des règles du jeu, il est probablement en O(CxV) quand la carte est suffisament grande.
 * 
 * Cet algorithme n'est probablement pas le plus efficace du point de vue du temps d'exécution.
 * En effet, à cause des règles du jeu, on V << C (V est beaucoup plus petit  que C). Il est
 * probablement plus pertinent de construire un algorithme parcourant les trésors et travaillant sur 
 * les cases autour de chaque trésors.
 *  
 */
public class DistanceValueClueSetter implements CluesSetter {
	private CaseMap lastMap;
	private Coordinates inspectedCoord;

	@Override
	public void setClues(CaseMap map) {
		lastMap = map;

		for (Coordinates coord : lastMap) {
			inspectedCoord = coord;
			inspectCoord();
		}
	}

	private void inspectCoord() {
		if (lastMap.isDiggableAndEmpty(inspectedCoord)) {
			Set<Coordinates> treasures = lastMap.getTreasuresAround(inspectedCoord);
			if (!treasures.isEmpty()) {
				Coordinates bestTreasure = findBestTreasure(treasures);
				Orientation clue = inspectedCoord.getOrientationTo(bestTreasure);
				lastMap.setClueAt(clue, inspectedCoord);
			}
		}
	}

	private Coordinates findBestTreasure(Iterable<Coordinates> treasuresCoords) {
		Coordinates bestCoord = Coordinates.ofRowAndCol(Integer.MAX_VALUE, Integer.MAX_VALUE);

		for (Coordinates candidateCoord : treasuresCoords) {
			bestCoord = chooseBestBetween(bestCoord, candidateCoord);
		}

		return bestCoord;
	}

	private Coordinates chooseBestBetween(Coordinates actualBest, Coordinates candidate) {
		// Double.compare(double) gère le cas où une coordonnée à une distance qui n'est
		// pas un nombre (Math.Nan).
		double distComparison = Double.compare(candidate.getDistanceTo(inspectedCoord),
				actualBest.getDistanceTo(inspectedCoord));
		double coinsComparison = lastMap.getTreasureAt(actualBest) - lastMap.getTreasureAt(candidate);

		Coordinates best = actualBest;

		if (distComparison < 0) {
			best = candidate;
		} else if (distComparison == 0) {
			if (coinsComparison < 0) {
				best = candidate;
			} else if (coinsComparison == 0 && candidate.compareTo(actualBest) < 0) {
				best = candidate;
			}
		}

		return best;
	}

}
