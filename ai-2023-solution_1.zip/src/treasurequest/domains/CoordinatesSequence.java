package treasurequest.domains;

import java.util.Collection;

/**
 * Représente une séquence infinie de coordonnées.
 * 
 * Cette interface sert à déterminer la position des trésors aléatoirement pendant le jeu ou de façon déterministe pendant les tests.
 * */
public interface CoordinatesSequence {
	/**
	 * Définit les coordonnées sélectionnable
	 * */
	void setSelectableCoords(Collection<Coordinates> coordinates);
	
	/**
	 * Retourne la prochaine coordonnée de la séquence.
	 * */
	Coordinates next();
}
