package treasurequest.domains;

import java.util.*;

import treasurequest.io.CharArrayFileReader;

/**
 * Fabrique une carte à partir d'un fichier.
 */
public class TxtFileCaseMapFactory implements CaseMapFactory {
	private final IntSequence sequence;

	private Map<Coordinates, Case> coord2Case;
	
	/**
	 * Construit une fabrique de cartes basée sur des fichiers txt à partir de la séquence {@code componentsSequence}.
	 * */
	public TxtFileCaseMapFactory(IntSequence coordsSequence) {
		sequence = coordsSequence;
		resetState();
	}
	
	/**
	 * Charge une carte depuis un fichier.
	 * 
	 * Retourne {@code CaseMap.SINGLE} si le chemin vers le fichier est null ou si
	 * la carte lue n'est pas jouable.
	 * 
	 * @param filePath le chemin vers le fichier
	 */
	@Override
	public CaseMap load(String filePath) {
		if (filePath == null) {
			return CaseMap.single();
		}

		char[][] mapArray = CharArrayFileReader.parseFile(filePath);
		return charArray2Map(mapArray);
	}
	
	/**
	 * Charge une carte depuis un fichier par extraction d'une sous-zone de {@code fragmentSize}.
	 * 
	 * Retourne {@code CaseMap.SINGLE} si le chemin vers le fichier est null ou si
	 * la carte lue n'est pas jouable.
	 * 
	 * @param filePath le chemin vers le fichier
	 * @param fragmentSize un entier positif indiquant la taille de la zone à extraire
	 */
	@Override
	public CaseMap load(String filePath, int fragmentSize) {
		if (filePath == null) {
			return CaseMap.single();
		}

		char[][] mapArray = extractArea(CharArrayFileReader.parseFile(filePath), fragmentSize);
		return charArray2Map(mapArray);
	}
	
	private CaseMap charArray2Map(char[][] mapArray) {
		if (isUnplayable(mapArray)) {
			return CaseMap.single();
		}
		parseCharArray(mapArray);
		
		return CaseMap.ofPairs(coord2Case);
	}


	private void parseCharArray(char[][] mapConfig) {
		resetState();
		
		for (int row = 0; row < mapConfig.length; row++) {
			for (int col = 0; col < mapConfig[row].length; col++) {
				insertCase(row, col, mapConfig[row][col]);
			}
		}
	}

	/* Insère une case à l'emplacment (row, col) du type donné. */
	private void insertCase(int row, int col, char type) {
		Coordinates coordinates = Coordinates.ofRowAndCol(row, col);
		CaseType caseType = getCaseTypeFromChar(type);
		Case caseObj = Case.ofType(caseType);

		coord2Case.put(coordinates, caseObj);
	}

	private final void resetState() {
		coord2Case = new HashMap<>();
	}
	
	private boolean isUnplayable(char[][] mapTable) {
		for (char[] row : mapTable) {
			for (char element : row) {
				if (element != 'X') {
					return false;
				}
			}
		}

		return true;
	}

	private char[][] extractArea(char[][] map, int areaSize) {
		int maxStartRow = map.length - areaSize;
		int maxStartCol = map[0].length - areaSize;

		int startRow = sequence.nextBetween(0, maxStartRow);
		int startCol = sequence.nextBetween(0, maxStartCol);

		char[][] area = new char[areaSize][areaSize];
		for (int rowIndex = 0; rowIndex < areaSize; rowIndex++) {
			for (int colIndex = 0; colIndex < areaSize; colIndex++) {
				area[rowIndex][colIndex] = map[startRow + rowIndex][startCol + colIndex];
			}
		}
		return area;
	}

	private CaseType getCaseTypeFromChar(char character) {
		switch (character) {
		case 'S':
			return CaseType.SAND;
		case 'P':
			return CaseType.GRASSLAND;
		case 'F':
			return CaseType.FOREST;
		case 'R':
			return CaseType.ROCK;
		default:
			return CaseType.WATER;
		}
	}

}
