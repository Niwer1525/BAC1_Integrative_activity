package treasurequest.domains;

/**
 * Représente une séquence infinie d'entiers.
 * 
 * Cette interface sert à déterminer la valeur des trésors aléatoirement pendant le jeu ou de façon déterministe pendant les tests.
 */
public interface IntSequence {
	/**
	 * Retourne un entier aléatoire compris entre min et max, {@code max} exclus.
	 */
	int nextBetween(int min, int max);
}
