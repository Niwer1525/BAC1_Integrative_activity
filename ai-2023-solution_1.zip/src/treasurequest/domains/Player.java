package treasurequest.domains;

import java.time.Duration;
import java.util.*;

/**
 * Représente un joueur  responsable de connaître sa position, 
 * ses revenus et dépenses et sa durée de jeu.
 */
/* 
* Choix de collection pour les cases visitées
* ============================================
* 
* Cette collection doit indiquer si une case a déjà été visitée.
* 
* Il n'y a pas besoin de parcours séquentiel ni d'accès sélectif.
* En outre, la présence de doublons n'a pas de sens.
* 
* En conséquence, nous optons pour une Set.
* 
* Choix de l'implémentation
* ===========================
* 
* Deux opérations seront utilisées : l'ajout d'un élément et la vérification de la présence d'un élément.
* Sur base du tableau ci-dessous, nous pouvons éliminer la TreeSet
* 
*              | add(T) | contains(T)|
*              |--------|------------|
* HashSet      | O(1)   | O(1)
* LinkedHashSet| O(1)   | O(1)
* TreeSet      | O(Lg N)| O(Lg N)
* 
* Pour les deux candidates restants, la HashSet offre de meilleures performances, car elle ne
* doit pas mémoriser l'ordre d'insertion des éléments.
* 
* En conclusion, nous optons pour la HashSet
*/
/*
 * = Nombre de coups idéals
 * 
 * TODO définir la notion de nombre de coups idéals
 * 
 * = Préconditions de l'efficacité
 * 
 * TODO définir les conditions à remplir pour calculer l'efficacité
 * 
 * = Postconditions
 * 
 * TODO définir les conditions que le résultat de l'efficacité doit remplir
 * 
 * */
public class Player {
	private final Map<Coordinates, CaseType> dugCases;
	private Coordinates position;   
    private Duration gameTime;    
    private int spentCoins;    
    private int receivedCoins;
    
    /**
     * Crée un objet Player avec une bourse initiale (coins) et une position de départ.
     */
    public Player(int coins, Coordinates position) {
    	this.dugCases = new LinkedHashMap<>();
        this.gameTime = Duration.ZERO;
        this.spentCoins = 0; 
        this.receivedCoins = coins;
        this.position = position;
    }
    
	/**
	 * Affecte une nouvelle position à ce joueur et vide les cases creusées.
	 * */
	public void reset(Coordinates newPosition) {
		this.position = Objects.requireNonNull(newPosition);		
		this.dugCases.clear();
	}
	
	/**
	 * Modifie la position de ce joueur de {@code (dRow, dCol)}.
	 * */
	public void move(int dRow, int dCol) {
		this.position = this.position.plus(dRow, dCol);
	}

	/**
	 * Retourne la position de ce joueur.
	 * */
	public Coordinates getPosition() {
		return this.position;
	}
    
	/**
	 * Retourne le montant de la bourse du joueur(nombre de coins).
	 * @return la bourse du joueur. 
	 */
	public int getCoins() {
		return this.receivedCoins - this.spentCoins;
	}
	
    /**
	 * Ajoute le nombre de pièces que le joueur à dépensé dans la partie.
	 * @param amount le nombre de pièces
	 */
   	public void spendCoins(int amount) {
   		this.spentCoins += amount; 
   	}
   	/**
	 * Retourne le nombre de pièces que le joueur à dépensé dans la partie.
	 * @return le nombre de pièces dépensées
	 */
   	public int getSpentCoins() {
   		return this.spentCoins;
   	}
   	/**
   	 * Ajoute un montant au nombre total de pièces que le joueur à reçu durant la partie.
   	 * @param amount le montant à ajouter
   	 */
   	public void receiveCoins(int amount) {
   	    this.receivedCoins += amount; 
   	}
   	/**
   	 * Retourne le total de pièces que le joueur à gagné durant la partie
   	 * @return le nombre total de pièces qu'il a gagné durant la partie 
   	 */
   	public int getReceivedCoins() {
   	    return this.receivedCoins;
   	}

    /**
	 * Ajoute du temps de jeu à la partie
	 * @param duration ajoute l'élipse de temps depuis le dernier ajout
	 */
    public void addGameTime(Duration duration) {
	   this.gameTime = gameTime.plus(Objects.requireNonNull(duration));
    }
   	
   	/**
	 * Retourne le temps de jeu 
	 * @return le temps de jeu 
	 */
    public Duration getGameTime() {
    	return gameTime;
    }

    /**
     * Creuse la case correspondant à sa position courante.
     * <ul>
     * <li>Retire le cout de cette case
     * <li>Ajoute le montant de cette case
     * <li>Ajoute cette case active à sa liste des case
     * */
	public void dig(CaseMap caseMap) {
		if(caseMap.isDiggableFor(getCoins(), position)) {
			caseMap.digAt(position);
			
			spentCoins += caseMap.getCaseCostAt(position);
			receivedCoins += caseMap.getTreasureAt(position);
			dugCases.put(position, caseMap.getCaseTypeAt(position));
		}
		
	}

	/**
	 * Retourne la plus grande zone creusée par ce joueur.
	 * */
	/* CTT de l'algorithme qui détermine la plus grande zone creusée
	 * ==============================================================
	 * 	
	 * Dans le pire des case, aucune case creusée n'est adjacente, chaque case correspondra à une zone. 
	 * 
	 * L'algorithme compte une boucle principale qui parcourt les C cases creusées (C répétitions).
	 * 
	 * Pour chaque case, l'algorithme génère ses A cases adjacentes. Pour chaque case adajacente, on détermine si elle appartient à la zone 
	 * (O(1) vu les opérations faites une LinkedHashMap). Dans le pire des cas, chaque case correspond à une zone différente ce qui fait que l'appel récursif s'arrete.
	 * 
	 * Enfin, la nouvelle zone est comparée à la plus grande zone courante. Cette opération est constante, car elle se limite
	 * à comparer les tailles des zones.
	 * 
	 * En conclusion, dans le pire des cas, l'algorithme à une CTT en O(CxA) où C correspond au nombre de cases creusées
	 * et A au nombre de cases adjacente à une case.
	 */
	public Zone getLargestZone() {
		Set<Coordinates> visited = new HashSet<>();
		Zone largestZone = Zone.EMPTY;
		
		for (var coord : dugCases.keySet()) {
			if (!visited.contains(coord)) {
				Zone newZone = new Zone(coord, dugCases.get(coord));
				
				exploreZoneFromCoord(newZone, coord, visited);

				largestZone = largestZone.largestBetween(newZone);
			}
		}

		return largestZone;
	}

	private void exploreZoneFromCoord(Zone zone, Coordinates coord, Set<Coordinates> visited) {		
		for (int i = -1; i <= 1; i++) {
			for (int j = -1; j <= 1; j++) {
				Coordinates nextCoord = Coordinates.ofRowAndCol(coord.getRow() + i, coord.getCol() + j);

				if (zone.hasSameType(dugCases.get(nextCoord)) && !visited.contains(nextCoord) ) {
					visited.add(nextCoord);
					zone.add(nextCoord);
					exploreZoneFromCoord(zone, nextCoord, visited);
				}
			}
		}
	}
}
