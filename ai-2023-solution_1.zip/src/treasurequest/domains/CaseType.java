package treasurequest.domains;

/**
 * Définit les différents types de Case (CaseType) présent sur la map. Chaque
 * type a un coût de creusage qui lui est associé.
 */
public enum CaseType {
	WATER(0), SAND(1), GRASSLAND(SAND.getCost()*2), FOREST(SAND.getCost()*3), ROCK(SAND.getCost()*5), UNKNOWN(0);
/**
 * Coût de creusage
 */
	private final int cost;

	/**
	 * Initialise un coût de creusage au type de case
	 * 
	 * @param cost le coût de creusage associé au type.
	 */
	CaseType(int cost) {
		this.cost = cost;
	}

	/**
	 * Retourne le coût de creusage du type de la Case
	 * 
	 * @return Le coût de creusage
	 */
	public int getCost() {
		return cost;
	}
}
